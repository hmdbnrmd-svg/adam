# مُدير التأجير — بناء ملف APK عبر GitHub Actions

## الخطوات السريعة (بدون أخطاء)
1. أنشئ مستودعاً جديداً على GitHub (يفضل Private للاستخدام الشخصي).
2. ارفع جميع ملفات هذا المجلد (تأكد من وجود مجلد .github/workflows/build-apk.yml وملف capacitor.config.json في المسار الرئيسي للمستودع).
3. ادخل إلى تبويب Actions في المستودع على GitHub.
4. اختر Workflow باسم "Build Android APK" واضغط Run workflow (أو سيبدأ تلقائياً فور الرفع على فرع main).
5. بعد انتهاء البناء وظهور علامة الصح الخضراء، انزل إلى قسم Artifacts وحمّل ملف app-rental-manager-apk ثم فك ضغطه وثبّت app-debug.apk على هاتفك الأندرويد.
