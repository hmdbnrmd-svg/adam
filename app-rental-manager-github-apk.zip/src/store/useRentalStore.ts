import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type {
  AppItem,
  AppNotification,
  AppSettings,
  Client,
  ClientDocument,
  Rating,
  Rental,
} from '../types/app';
import { addMonthsToDate, daysUntil, generateId, todayISO } from '../utils/helpers';

const STORAGE_KEY = 'app_rental_manager_v1';

interface StoreState {
  apps: AppItem[];
  clients: Client[];
  rentals: Rental[];
  ratings: Rating[];
  settings: AppSettings;
}

function addDaysISO(baseISO: string, days: number): string {
  const d = new Date(baseISO);
  d.setDate(d.getDate() + days);
  return d.toISOString().split('T')[0];
}

function createInitialData(): StoreState {
  const today = todayISO();
  const app1Id = 'app_design_pro';
  const app2Id = 'app_pos_cloud';
  const app3Id = 'app_stream_suite';

  const client1Id = 'client_ahmed';
  const client2Id = 'client_sara';
  const client3Id = 'client_khalid';

  return {
    apps: [
      {
        id: app1Id,
        name: 'حزمة التصميم الاحترافية',
        category: 'تصميم ومونتاج',
        monthlyPrice: 45,
        totalSlots: 10,
        description: 'اشتراك شهري متكامل لتطبيقات التصميم والمونتاج مع دعم فني.',
        createdAt: today,
      },
      {
        id: app2Id,
        name: 'نظام الكاشير والمبيعات',
        category: 'أعمال ومبيعات',
        monthlyPrice: 80,
        totalSlots: 8,
        description: 'تطبيق نقاط بيع وإدارة مخزون للمتاجر والمشاريع.',
        createdAt: today,
      },
      {
        id: app3Id,
        name: 'تطبيق الحماية والخصوصية',
        category: 'أدوات وحماية',
        monthlyPrice: 30,
        totalSlots: 15,
        description: 'حساب عائلي وشخصي بأداء سريع وتشفير كامل.',
        createdAt: today,
      },
    ],
    clients: [
      {
        id: client1Id,
        name: 'أحمد العتيبي',
        whatsapp: '966501234567',
        extraContact: 'تيليجرام: @ahmed_otb',
        notes: 'عميل دائم وملتزم بموعد التجديد الشهري.',
        documents: [
          {
            id: 'doc_1',
            title: 'اتفاقية التأجير الأولية',
            type: 'note',
            noteText: 'تم الاتفاق على التجديد التلقائي بداية كل شهر ميلادي مع تحويل بنكي مباشر.',
            addedAt: today,
          },
        ],
        createdAt: today,
      },
      {
        id: client2Id,
        name: 'سارة المنصور',
        whatsapp: '966559876543',
        extraContact: 'متجر إلكتروني — تواصل مسائي',
        notes: 'تستأجر باقة التصميم لفريق المتجر.',
        documents: [],
        createdAt: today,
      },
      {
        id: client3Id,
        name: 'خالد الدوسري',
        whatsapp: '966541122334',
        extraContact: '0541122334 (اتصال)',
        notes: 'يفضل التذكير قبل انتهاء الاشتراك بيومين عبر واتساب.',
        documents: [],
        createdAt: today,
      },
    ],
    rentals: [
      {
        id: 'rent_1',
        clientId: client1Id,
        appId: app2Id,
        appName: 'نظام الكاشير والمبيعات',
        price: 80,
        billingCycle: 'monthly',
        startDate: addDaysISO(today, -28),
        endDate: addDaysISO(today, 2),
        paymentStatus: 'paid',
        accountInfo: 'جهاز iPad Pro — فرع الرياض',
        createdAt: today,
      },
      {
        id: 'rent_2',
        clientId: client1Id,
        appId: app3Id,
        appName: 'تطبيق الحماية والخصوصية',
        price: 30,
        billingCycle: 'monthly',
        startDate: addDaysISO(today, -10),
        endDate: addDaysISO(today, 20),
        paymentStatus: 'paid',
        accountInfo: 'هاتف شخصي',
        createdAt: today,
      },
      {
        id: 'rent_3',
        clientId: client2Id,
        appId: app1Id,
        appName: 'حزمة التصميم الاحترافية',
        price: 45,
        billingCycle: 'monthly',
        startDate: addDaysISO(today, -12),
        endDate: addDaysISO(today, 18),
        paymentStatus: 'paid',
        accountInfo: 'حساب متجر سارة',
        createdAt: today,
      },
      {
        id: 'rent_4',
        clientId: client3Id,
        appId: app1Id,
        appName: 'حزمة التصميم الاحترافية',
        price: 45,
        billingCycle: 'monthly',
        startDate: addDaysISO(today, -32),
        endDate: addDaysISO(today, -1),
        paymentStatus: 'pending',
        accountInfo: 'جهاز أندرويد',
        notes: 'بانتظار تحويل التجديد',
        createdAt: today,
      },
    ],
    ratings: [
      {
        id: 'rat_1',
        clientId: client1Id,
        appName: 'نظام الكاشير والمبيعات',
        score: 5,
        commitmentTag: 'ملتزم',
        comment: 'تحويل فوري قبل موعد التجديد وتواصل راقي جداً.',
        createdAt: today,
      },
      {
        id: 'rat_2',
        clientId: client2Id,
        appName: 'حزمة التصميم الاحترافية',
        score: 5,
        commitmentTag: 'ملتزم',
        comment: 'دفع منتظم واستخدام نظامي بدون أي مشاكل.',
        createdAt: today,
      },
      {
        id: 'rat_3',
        clientId: client3Id,
        appName: 'حزمة التصميم الاحترافية',
        score: 3,
        commitmentTag: 'تأخير بسيط',
        comment: 'يحتاج إلى رسالة تذكير قبل انتهاء الاشتراك بيومين.',
        createdAt: today,
      },
    ],
    settings: {
      appTitle: 'مُدير التأجير',
      currency: 'ر.س',
      reminderDays: 3,
      darkMode: false,
    },
  };
}

function loadState(): StoreState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createInitialData();
    const parsed = JSON.parse(raw) as Partial<StoreState>;
    const fallback = createInitialData();
    return {
      apps: Array.isArray(parsed.apps) ? parsed.apps : fallback.apps,
      clients: Array.isArray(parsed.clients) ? parsed.clients : fallback.clients,
      rentals: Array.isArray(parsed.rentals) ? parsed.rentals : fallback.rentals,
      ratings: Array.isArray(parsed.ratings) ? parsed.ratings : fallback.ratings,
      settings: parsed.settings ? { ...fallback.settings, ...parsed.settings } : fallback.settings,
    };
  } catch {
    return createInitialData();
  }
}

interface RentalStoreContextValue extends StoreState {
  notifications: AppNotification[];
  addApp: (data: Omit<AppItem, 'id' | 'createdAt'>) => AppItem;
  updateApp: (id: string, patch: Partial<AppItem>) => void;
  deleteApp: (id: string) => void;
  addClient: (data: Omit<Client, 'id' | 'createdAt' | 'documents'>) => Client;
  updateClient: (id: string, patch: Partial<Client>) => void;
  deleteClient: (id: string) => void;
  addClientDocument: (clientId: string, doc: Omit<ClientDocument, 'id' | 'addedAt'>) => void;
  deleteClientDocument: (clientId: string, docId: string) => void;
  addRental: (data: Omit<Rental, 'id' | 'createdAt'>) => Rental;
  updateRental: (id: string, patch: Partial<Rental>) => void;
  renewRental: (id: string, months?: number) => void;
  deleteRental: (id: string) => void;
  addRating: (data: Omit<Rating, 'id' | 'createdAt'>) => Rating;
  deleteRating: (id: string) => void;
  updateSettings: (patch: Partial<AppSettings>) => void;
  exportBackupJson: () => string;
  importBackupJson: (jsonStr: string) => boolean;
  clearAllData: () => void;
  restoreDemoData: () => void;
}

const RentalStoreContext = createContext<RentalStoreContextValue | null>(null);

export const RentalStoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<StoreState>(() => loadState());

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // Ignore storage quota warnings gracefully
    }
  }, [state]);

  useEffect(() => {
    const root = document.documentElement;
    if (state.settings.darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [state.settings.darkMode]);

  const notifications = useMemo<AppNotification[]>(() => {
    const clientMap = new Map(state.clients.map((c) => [c.id, c]));
    const list: AppNotification[] = [];

    for (const rental of state.rentals) {
      const client = clientMap.get(rental.clientId);
      if (!client) continue;
      const diff = daysUntil(rental.endDate);

      if (diff < 0) {
        list.push({
          id: `notif_${rental.id}`,
          rentalId: rental.id,
          clientId: client.id,
          clientName: client.name,
          clientWhatsapp: client.whatsapp,
          appName: rental.appName,
          endDate: rental.endDate,
          daysRemaining: diff,
          severity: 'expired',
          message: `انتهى اشتراك ${rental.appName} منذ ${Math.abs(diff)} ${Math.abs(diff) === 1 ? 'يوم' : 'أيام'}`,
        });
      } else if (diff <= state.settings.reminderDays) {
        list.push({
          id: `notif_${rental.id}`,
          rentalId: rental.id,
          clientId: client.id,
          clientName: client.name,
          clientWhatsapp: client.whatsapp,
          appName: rental.appName,
          endDate: rental.endDate,
          daysRemaining: diff,
          severity: 'soon',
          message:
            diff === 0
              ? `ينتهي اشتراك ${rental.appName} اليوم`
              : `ينتهي اشتراك ${rental.appName} خلال ${diff} ${diff === 1 ? 'يوم' : 'أيام'}`,
        });
      } else if (rental.paymentStatus !== 'paid') {
        list.push({
          id: `notif_${rental.id}`,
          rentalId: rental.id,
          clientId: client.id,
          clientName: client.name,
          clientWhatsapp: client.whatsapp,
          appName: rental.appName,
          endDate: rental.endDate,
          daysRemaining: diff,
          severity: 'unpaid',
          message: `اشتراك ${rental.appName} بانتظار تأكيد السداد`,
        });
      }
    }

    return list.sort((a, b) => a.daysRemaining - b.daysRemaining);
  }, [state.rentals, state.clients, state.settings.reminderDays]);

  const addApp = (data: Omit<AppItem, 'id' | 'createdAt'>): AppItem => {
    const newApp: AppItem = {
      ...data,
      id: generateId('app'),
      createdAt: todayISO(),
    };
    setState((prev) => ({ ...prev, apps: [newApp, ...prev.apps] }));
    return newApp;
  };

  const updateApp = (id: string, patch: Partial<AppItem>) => {
    setState((prev) => ({
      ...prev,
      apps: prev.apps.map((a) => (a.id === id ? { ...a, ...patch } : a)),
    }));
  };

  const deleteApp = (id: string) => {
    setState((prev) => ({
      ...prev,
      apps: prev.apps.filter((a) => a.id !== id),
    }));
  };

  const addClient = (data: Omit<Client, 'id' | 'createdAt' | 'documents'>): Client => {
    const newClient: Client = {
      ...data,
      id: generateId('cli'),
      documents: [],
      createdAt: todayISO(),
    };
    setState((prev) => ({ ...prev, clients: [newClient, ...prev.clients] }));
    return newClient;
  };

  const updateClient = (id: string, patch: Partial<Client>) => {
    setState((prev) => ({
      ...prev,
      clients: prev.clients.map((c) => (c.id === id ? { ...c, ...patch } : c)),
    }));
  };

  const deleteClient = (id: string) => {
    setState((prev) => ({
      ...prev,
      clients: prev.clients.filter((c) => c.id !== id),
      rentals: prev.rentals.filter((r) => r.clientId !== id),
      ratings: prev.ratings.filter((rt) => rt.clientId !== id),
    }));
  };

  const addClientDocument = (clientId: string, doc: Omit<ClientDocument, 'id' | 'addedAt'>) => {
    const newDoc: ClientDocument = {
      ...doc,
      id: generateId('doc'),
      addedAt: todayISO(),
    };
    setState((prev) => ({
      ...prev,
      clients: prev.clients.map((c) =>
        c.id === clientId ? { ...c, documents: [newDoc, ...c.documents] } : c
      ),
    }));
  };

  const deleteClientDocument = (clientId: string, docId: string) => {
    setState((prev) => ({
      ...prev,
      clients: prev.clients.map((c) =>
        c.id === clientId
          ? { ...c, documents: c.documents.filter((d) => d.id !== docId) }
          : c
      ),
    }));
  };

  const addRental = (data: Omit<Rental, 'id' | 'createdAt'>): Rental => {
    const newRental: Rental = {
      ...data,
      id: generateId('rent'),
      createdAt: todayISO(),
    };
    setState((prev) => ({ ...prev, rentals: [newRental, ...prev.rentals] }));
    return newRental;
  };

  const updateRental = (id: string, patch: Partial<Rental>) => {
    setState((prev) => ({
      ...prev,
      rentals: prev.rentals.map((r) => (r.id === id ? { ...r, ...patch } : r)),
    }));
  };

  const renewRental = (id: string, months = 1) => {
    setState((prev) => ({
      ...prev,
      rentals: prev.rentals.map((r) => {
        if (r.id !== id) return r;
        const base = daysUntil(r.endDate) > 0 ? r.endDate : todayISO();
        return {
          ...r,
          endDate: addMonthsToDate(base, months),
          paymentStatus: 'paid',
        };
      }),
    }));
  };

  const deleteRental = (id: string) => {
    setState((prev) => ({
      ...prev,
      rentals: prev.rentals.filter((r) => r.id !== id),
    }));
  };

  const addRating = (data: Omit<Rating, 'id' | 'createdAt'>): Rating => {
    const newRating: Rating = {
      ...data,
      id: generateId('rat'),
      createdAt: todayISO(),
    };
    setState((prev) => ({ ...prev, ratings: [newRating, ...prev.ratings] }));
    return newRating;
  };

  const deleteRating = (id: string) => {
    setState((prev) => ({
      ...prev,
      ratings: prev.ratings.filter((r) => r.id !== id),
    }));
  };

  const updateSettings = (patch: Partial<AppSettings>) => {
    setState((prev) => ({
      ...prev,
      settings: { ...prev.settings, ...patch },
    }));
  };

  const exportBackupJson = () => JSON.stringify(state, null, 2);

  const importBackupJson = (jsonStr: string): boolean => {
    try {
      const parsed = JSON.parse(jsonStr) as Partial<StoreState>;
      if (!Array.isArray(parsed.clients) || !Array.isArray(parsed.apps)) {
        return false;
      }
      setState((prev) => ({
        apps: parsed.apps ?? prev.apps,
        clients: parsed.clients ?? prev.clients,
        rentals: Array.isArray(parsed.rentals) ? parsed.rentals : prev.rentals,
        ratings: Array.isArray(parsed.ratings) ? parsed.ratings : prev.ratings,
        settings: parsed.settings ? { ...prev.settings, ...parsed.settings } : prev.settings,
      }));
      return true;
    } catch {
      return false;
    }
  };

  const clearAllData = () => {
    setState((prev) => ({
      apps: [],
      clients: [],
      rentals: [],
      ratings: [],
      settings: prev.settings,
    }));
  };

  const restoreDemoData = () => {
    setState(createInitialData());
  };

  return React.createElement(
    RentalStoreContext.Provider,
    {
      value: {
        ...state,
        notifications,
        addApp,
        updateApp,
        deleteApp,
        addClient,
        updateClient,
        deleteClient,
        addClientDocument,
        deleteClientDocument,
        addRental,
        updateRental,
        renewRental,
        deleteRental,
        addRating,
        deleteRating,
        updateSettings,
        exportBackupJson,
        importBackupJson,
        clearAllData,
        restoreDemoData,
      },
    },
    children
  );
};

export function useRentalStore(): RentalStoreContextValue {
  const ctx = useContext(RentalStoreContext);
  if (!ctx) {
    throw new Error('useRentalStore must be used inside RentalStoreProvider');
  }
  return ctx;
}
