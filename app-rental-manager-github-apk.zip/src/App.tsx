import React, { useState } from 'react';
import { ApkGithubGuideView } from './components/ApkGithubGuideView';
import { AppsView } from './components/AppsView';
import { AddClientView } from './components/AddClientView';
import { BottomNav } from './components/BottomNav';
import { ClientDetailsView } from './components/ClientDetailsView';
import { ClientsView } from './components/ClientsView';
import { HomeView } from './components/HomeView';
import { NotificationsSheet } from './components/NotificationsSheet';
import { OfflineIndicator } from './components/OfflineIndicator';
import { QuickAddSheet } from './components/QuickAddSheet';
import { RatingsView } from './components/RatingsView';
import { RentalModal } from './components/RentalModal';
import { SideDrawer } from './components/SideDrawer';
import { TopBar } from './components/TopBar';
import { RentalStoreProvider, useRentalStore } from './store/useRentalStore';
import type { ActivePage, MainTab, Rental } from './types/app';

const AppShell: React.FC = () => {
  const { settings, notifications } = useRentalStore();
  const [page, setPage] = useState<ActivePage>({ type: 'tab', tab: 'home' });
  const [lastTab, setLastTab] = useState<MainTab>('home');

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [quickAddOpen, setQuickAddOpen] = useState(false);

  const [rentalModalOpen, setRentalModalOpen] = useState(false);
  const [rentalDefaultClientId, setRentalDefaultClientId] = useState<string | undefined>();
  const [rentalDefaultAppId, setRentalDefaultAppId] = useState<string | undefined>();
  const [editingRental, setEditingRental] = useState<Rental | null>(null);

  const [addAppSignal, setAddAppSignal] = useState(0);
  const [addRatingSignal, setAddRatingSignal] = useState(0);

  const goToTab = (tab: MainTab) => {
    setLastTab(tab);
    setPage({ type: 'tab', tab });
  };

  const openClientDetails = (clientId: string) => {
    setPage({ type: 'client-details', clientId });
  };

  const openAddClient = (editClientId?: string) => {
    setPage({ type: 'add-client', editClientId });
  };

  const openRentalModal = (opts?: {
    clientId?: string;
    appId?: string;
    rental?: Rental;
  }) => {
    setRentalDefaultClientId(opts?.clientId);
    setRentalDefaultAppId(opts?.appId);
    setEditingRental(opts?.rental ?? null);
    setRentalModalOpen(true);
  };

  const activeTab: MainTab | null = page.type === 'tab' ? page.tab : null;
  const showBack = page.type !== 'tab';

  const handleBack = () => {
    if (page.type === 'add-client' && page.editClientId) {
      setPage({ type: 'client-details', clientId: page.editClientId });
    } else if (page.type === 'add-client') {
      goToTab('clients');
    } else if (page.type === 'client-details') {
      goToTab(lastTab === 'home' ? 'clients' : lastTab);
    } else if (page.type === 'apk-github') {
      goToTab(lastTab);
    }
  };

  const topBarTitle =
    page.type === 'add-client'
      ? page.editClientId
        ? 'تعديل عميل'
        : 'إضافة عميل'
      : page.type === 'client-details'
      ? 'صفحة العميل'
      : page.type === 'apk-github'
      ? 'بناء APK عبر GitHub'
      : settings.appTitle || 'مُدير التأجير';

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      <TopBar
        title={topBarTitle}
        showBack={showBack}
        onBack={handleBack}
        onOpenDrawer={() => setDrawerOpen(true)}
        onOpenNotifications={() => setNotificationsOpen(true)}
        notificationCount={notifications.length}
      />

      <main className="mx-auto max-w-5xl px-3.5 pt-4 pb-28 sm:px-6">
        <OfflineIndicator />

        {page.type === 'tab' && page.tab === 'home' && (
          <HomeView
            onOpenClient={openClientDetails}
            onAddClient={() => openAddClient()}
            onAddRental={() => openRentalModal()}
            onNavigateTab={(t) => goToTab(t)}
          />
        )}

        {page.type === 'tab' && page.tab === 'apps' && (
          <AppsView
            externalOpenAddSignal={addAppSignal}
            onRentApp={(appId) => openRentalModal({ appId })}
          />
        )}

        {page.type === 'tab' && page.tab === 'clients' && (
          <ClientsView
            onAddClient={() => openAddClient()}
            onOpenClientDetails={openClientDetails}
          />
        )}

        {page.type === 'tab' && page.tab === 'ratings' && (
          <RatingsView
            externalOpenAddSignal={addRatingSignal}
            onOpenClient={openClientDetails}
          />
        )}

        {page.type === 'add-client' && (
          <AddClientView
            editClientId={page.editClientId}
            onDone={(id) => {
              if (id) {
                openClientDetails(id);
              } else {
                goToTab('clients');
              }
            }}
            onCancel={handleBack}
          />
        )}

        {page.type === 'client-details' && (
          <ClientDetailsView
            clientId={page.clientId}
            onEditClient={(id) => openAddClient(id)}
            onClientDeleted={() => goToTab('clients')}
            onAddRentalForClient={(id) => openRentalModal({ clientId: id })}
            onEditRental={(rental) => openRentalModal({ clientId: rental.clientId, rental })}
          />
        )}

        {page.type === 'apk-github' && <ApkGithubGuideView />}
      </main>

      <BottomNav
        activeTab={activeTab}
        onSelectTab={goToTab}
        onOpenQuickAdd={() => setQuickAddOpen(true)}
      />

      <SideDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        onOpenApkGithub={() => setPage({ type: 'apk-github' })}
      />

      <NotificationsSheet
        open={notificationsOpen}
        onClose={() => setNotificationsOpen(false)}
        onOpenClient={openClientDetails}
      />

      <QuickAddSheet
        open={quickAddOpen}
        onClose={() => setQuickAddOpen(false)}
        onAddClient={() => openAddClient()}
        onAddRental={() => openRentalModal()}
        onAddApp={() => {
          goToTab('apps');
          setAddAppSignal((s) => s + 1);
        }}
        onAddRating={() => {
          goToTab('ratings');
          setAddRatingSignal((s) => s + 1);
        }}
      />

      <RentalModal
        open={rentalModalOpen}
        onClose={() => setRentalModalOpen(false)}
        defaultClientId={rentalDefaultClientId}
        defaultAppId={rentalDefaultAppId}
        editingRental={editingRental}
      />
    </div>
  );
};

export default function App() {
  return (
    <RentalStoreProvider>
      <AppShell />
    </RentalStoreProvider>
  );
}
