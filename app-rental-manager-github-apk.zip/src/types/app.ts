export type BillingCycle = 'monthly' | 'quarterly' | 'yearly' | 'custom';
export type PaymentStatus = 'paid' | 'pending' | 'overdue';
export type CommitmentTag = 'ملتزم' | 'تأخير بسيط' | 'يحتاج متابعة';

export interface AppItem {
  id: string;
  name: string;
  category: string;
  monthlyPrice: number;
  description?: string;
  totalSlots: number;
  notes?: string;
  createdAt: string;
}

export interface ClientDocument {
  id: string;
  title: string;
  type: 'image' | 'file' | 'note';
  dataUrl?: string;
  fileName?: string;
  noteText?: string;
  addedAt: string;
}

export interface Client {
  id: string;
  name: string;
  avatarDataUrl?: string;
  whatsapp: string;
  extraContact?: string;
  notes: string;
  documents: ClientDocument[];
  createdAt: string;
}

export interface Rental {
  id: string;
  clientId: string;
  appId?: string;
  appName: string;
  price: number;
  billingCycle: BillingCycle;
  startDate: string;
  endDate: string;
  paymentStatus: PaymentStatus;
  accountInfo?: string;
  notes?: string;
  createdAt: string;
}

export interface Rating {
  id: string;
  clientId: string;
  appName: string;
  score: number;
  commitmentTag: CommitmentTag;
  comment: string;
  createdAt: string;
}

export interface AppSettings {
  appTitle: string;
  currency: string;
  reminderDays: number;
  darkMode: boolean;
}

export type MainTab = 'home' | 'apps' | 'clients' | 'ratings';
export type ActivePage =
  | { type: 'tab'; tab: MainTab }
  | { type: 'add-client'; editClientId?: string }
  | { type: 'client-details'; clientId: string }
  | { type: 'apk-github' };

export interface AppNotification {
  id: string;
  rentalId: string;
  clientId: string;
  clientName: string;
  clientWhatsapp: string;
  appName: string;
  endDate: string;
  daysRemaining: number;
  severity: 'expired' | 'soon' | 'unpaid';
  message: string;
}
