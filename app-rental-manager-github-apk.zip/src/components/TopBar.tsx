import React from 'react';
import { ArrowRight, Bell, Menu } from 'lucide-react';

interface TopBarProps {
  title: string;
  showBack?: boolean;
  onBack?: () => void;
  onOpenDrawer: () => void;
  onOpenNotifications: () => void;
  notificationCount: number;
}

export const TopBar: React.FC<TopBarProps> = ({
  title,
  showBack = false,
  onBack,
  onOpenDrawer,
  onOpenNotifications,
  notificationCount,
}) => {
  return (
    <header className="sticky top-0 z-30 h-14 border-b border-slate-200 bg-white/95 backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/95">
      <div className="mx-auto flex h-full max-w-5xl items-center justify-between px-3 sm:px-6">
        {/* Right side in RTL: 3-line side menu icon (or Back button on sub-pages alongside menu) */}
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={onOpenDrawer}
            aria-label="القائمة الجانبية"
            className="flex h-11 w-11 items-center justify-center rounded-xl text-slate-700 transition-colors hover:bg-slate-100 active:bg-slate-200 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            <Menu className="h-6 w-6" />
          </button>
          {showBack && onBack && (
            <button
              type="button"
              onClick={onBack}
              aria-label="رجوع"
              className="flex h-11 w-11 items-center justify-center rounded-xl text-slate-700 transition-colors hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <ArrowRight className="h-5 w-5" />
            </button>
          )}
        </div>

        {/* Center: App Name */}
        <h1 className="font-display max-w-[55%] truncate text-base sm:text-lg font-bold tracking-tight text-slate-900 dark:text-white">
          {title}
        </h1>

        {/* Left side in RTL: Notification Icon ONLY */}
        <button
          type="button"
          onClick={onOpenNotifications}
          aria-label="التنبيهات"
          className="relative flex h-11 w-11 items-center justify-center rounded-xl text-slate-700 transition-colors hover:bg-slate-100 active:bg-slate-200 dark:text-slate-200 dark:hover:bg-slate-800"
        >
          <Bell className="h-5 w-5" />
          {notificationCount > 0 && (
            <span className="tabular-nums absolute top-1.5 left-1.5 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-rose-600 px-1 text-[10px] font-bold leading-none text-white">
              {notificationCount > 9 ? '9+' : notificationCount}
            </span>
          )}
        </button>
      </div>
    </header>
  );
};
