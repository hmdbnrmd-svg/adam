import React, { useRef, useState } from 'react';
import {
  Download,
  FolderArchive,
  Moon,
  RotateCcw,
  Sun,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { useRentalStore } from '../store/useRentalStore';
import { PWAInstallButton } from './PWAInstallButton';

interface SideDrawerProps {
  open: boolean;
  onClose: () => void;
  onOpenApkGithub: () => void;
}

export const SideDrawer: React.FC<SideDrawerProps> = ({ open, onClose, onOpenApkGithub }) => {
  const {
    settings,
    updateSettings,
    exportBackupJson,
    importBackupJson,
    clearAllData,
    restoreDemoData,
    clients,
    rentals,
    apps,
  } = useRentalStore();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);

  if (!open) return null;

  const handleExport = () => {
    const json = exportBackupJson();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `app-rental-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setFeedback('تم تصدير النسخة الاحتياطية بنجاح.');
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    const ok = importBackupJson(text);
    setFeedback(
      ok ? 'تم استيراد البيانات بنجاح.' : 'ملف النسخة الاحتياطية غير صالح.'
    );
    e.target.value = '';
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-start bg-slate-950/55 backdrop-blur-xs"
      onClick={onClose}
    >
      <aside
        aria-label="القائمة الجانبية"
        className="flex h-full w-[86%] max-w-sm flex-col border-l border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-900"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4 dark:border-slate-800">
          <div>
            <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
              {settings.appTitle}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              استخدام شخصي · حفظ محلي على الجهاز
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق القائمة"
            className="flex h-11 w-11 items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 space-y-5 overflow-y-auto p-5">
          {/* Install PWA CTA + GitHub APK Export */}
          <div className="space-y-2.5">
            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              التثبيت واستخراج APK
            </div>
            <PWAInstallButton variant="card" />

            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenApkGithub();
              }}
              className="flex w-full items-center justify-between gap-3 rounded-xl border border-slate-200 bg-slate-900 px-4 py-3 text-right text-white transition-colors hover:bg-slate-800 active:scale-[0.99] dark:border-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700"
            >
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-white/10">
                  <FolderArchive className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-sm font-semibold">بناء ملف APK عبر GitHub</div>
                  <div className="text-xs text-slate-300">
                    تحميل كل الملفات + الأوامر + طريقة التصدير كاملة
                  </div>
                </div>
              </div>
              <Download className="h-4 w-4 shrink-0 text-slate-300" />
            </button>
          </div>

          {/* Quick Overview */}
          <div className="grid grid-cols-3 gap-2 rounded-xl border border-slate-200 bg-slate-50 p-3 text-center dark:border-slate-800 dark:bg-slate-800/50">
            <div>
              <div className="tabular-nums text-base font-bold text-slate-900 dark:text-white">
                {clients.length}
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">العملاء</div>
            </div>
            <div className="border-x border-slate-200 dark:border-slate-700">
              <div className="tabular-nums text-base font-bold text-slate-900 dark:text-white">
                {apps.length}
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">التطبيقات</div>
            </div>
            <div>
              <div className="tabular-nums text-base font-bold text-slate-900 dark:text-white">
                {rentals.length}
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">الاشتراكات</div>
            </div>
          </div>

          {/* Preferences */}
          <div className="space-y-3">
            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              إعدادات عامة
            </div>

            <button
              type="button"
              onClick={() => updateSettings({ darkMode: !settings.darkMode })}
              className="flex min-h-[44px] w-full items-center justify-between rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-medium text-slate-800 hover:bg-slate-50 dark:border-slate-800 dark:text-slate-200 dark:hover:bg-slate-800/60"
            >
              <span className="flex items-center gap-2.5">
                {settings.darkMode ? (
                  <Sun className="h-4 w-4 text-amber-500" />
                ) : (
                  <Moon className="h-4 w-4 text-slate-600" />
                )}
                {settings.darkMode ? 'تفعيل الوضع الفاتح' : 'تفعيل الوضع الداكن'}
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                {settings.darkMode ? 'داكن' : 'فاتح'}
              </span>
            </button>

            <div className="rounded-xl border border-slate-200 p-3.5 space-y-3 dark:border-slate-800">
              <label className="block">
                <span className="text-xs font-medium text-slate-600 dark:text-slate-400">
                  اسم التطبيق في الشريط العلوي
                </span>
                <input
                  type="text"
                  value={settings.appTitle}
                  onChange={(e) => updateSettings({ appTitle: e.target.value })}
                  className="mt-1.5 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </label>

              <div className="grid grid-cols-2 gap-2.5">
                <label className="block">
                  <span className="text-xs font-medium text-slate-600 dark:text-slate-400">
                    العملة
                  </span>
                  <input
                    type="text"
                    value={settings.currency}
                    onChange={(e) => updateSettings({ currency: e.target.value })}
                    className="mt-1.5 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </label>

                <label className="block">
                  <span className="text-xs font-medium text-slate-600 dark:text-slate-400">
                    تنبيه قبل الانتهاء (يوم)
                  </span>
                  <input
                    type="number"
                    min={1}
                    max={30}
                    value={settings.reminderDays}
                    onChange={(e) =>
                      updateSettings({ reminderDays: Math.max(1, Number(e.target.value) || 3) })
                    }
                    className="tabular-nums mt-1.5 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </label>
              </div>
            </div>
          </div>

          {/* Backup & Data */}
          <div className="space-y-2.5">
            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              النسخ الاحتياطي والبيانات
            </div>

            <button
              type="button"
              onClick={handleExport}
              className="flex min-h-[44px] w-full items-center gap-2.5 rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-medium text-slate-800 hover:bg-slate-50 dark:border-slate-800 dark:text-slate-200 dark:hover:bg-slate-800/60"
            >
              <Download className="h-4 w-4 text-teal-600 dark:text-teal-400" />
              <span>تصدير نسخة احتياطية (JSON)</span>
            </button>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex min-h-[44px] w-full items-center gap-2.5 rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-medium text-slate-800 hover:bg-slate-50 dark:border-slate-800 dark:text-slate-200 dark:hover:bg-slate-800/60"
            >
              <Upload className="h-4 w-4 text-teal-600 dark:text-teal-400" />
              <span>استيراد نسخة احتياطية</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="application/json,.json"
              onChange={handleImportFile}
              className="hidden"
            />

            <button
              type="button"
              onClick={() => {
                restoreDemoData();
                setFeedback('تمت استعادة البيانات الافتراضية.');
              }}
              className="flex min-h-[44px] w-full items-center gap-2.5 rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-800/60"
            >
              <RotateCcw className="h-4 w-4 text-slate-500" />
              <span>استعادة بيانات تجريبية</span>
            </button>

            {!confirmClear ? (
              <button
                type="button"
                onClick={() => setConfirmClear(true)}
                className="flex min-h-[44px] w-full items-center gap-2.5 rounded-xl border border-rose-200 px-3.5 py-2.5 text-sm font-medium text-rose-700 hover:bg-rose-50 dark:border-rose-900/60 dark:text-rose-400 dark:hover:bg-rose-950/30"
              >
                <Trash2 className="h-4 w-4" />
                <span>مسح جميع البيانات والبدء من الصفر</span>
              </button>
            ) : (
              <div className="rounded-xl border border-rose-300 bg-rose-50 p-3 text-xs dark:border-rose-800 dark:bg-rose-950/50">
                <p className="font-medium text-rose-900 dark:text-rose-200">
                  هل أنت متأكد؟ سيتم حذف جميع العملاء والتطبيقات المحفوظة.
                </p>
                <div className="mt-2.5 flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      clearAllData();
                      setConfirmClear(false);
                      setFeedback('تم مسح جميع البيانات.');
                    }}
                    className="flex-1 rounded-lg bg-rose-600 py-2 font-medium text-white hover:bg-rose-700"
                  >
                    نعم، مسح الكل
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmClear(false)}
                    className="flex-1 rounded-lg border border-slate-300 bg-white py-2 font-medium text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                  >
                    إلغاء
                  </button>
                </div>
              </div>
            )}

            {feedback && (
              <p className="rounded-lg bg-teal-50 px-3 py-2 text-xs font-medium text-teal-800 dark:bg-teal-950/50 dark:text-teal-300">
                {feedback}
              </p>
            )}
          </div>
        </div>
      </aside>
    </div>
  );
};
