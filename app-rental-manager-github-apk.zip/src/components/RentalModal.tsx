import React, { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { useRentalStore } from '../store/useRentalStore';
import type { BillingCycle, PaymentStatus, Rental } from '../types/app';
import { addMonthsToDate, todayISO } from '../utils/helpers';

interface RentalModalProps {
  open: boolean;
  onClose: () => void;
  defaultClientId?: string;
  defaultAppId?: string;
  editingRental?: Rental | null;
}

export const RentalModal: React.FC<RentalModalProps> = ({
  open,
  onClose,
  defaultClientId,
  defaultAppId,
  editingRental,
}) => {
  const { clients, apps, settings, addRental, updateRental } = useRentalStore();

  const [clientId, setClientId] = useState('');
  const [selectedAppId, setSelectedAppId] = useState('');
  const [customAppName, setCustomAppName] = useState('');
  const [price, setPrice] = useState('');
  const [billingCycle, setBillingCycle] = useState<BillingCycle>('monthly');
  const [startDate, setStartDate] = useState(todayISO());
  const [endDate, setEndDate] = useState(addMonthsToDate(todayISO(), 1));
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>('paid');
  const [accountInfo, setAccountInfo] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!open) return;
    setError('');
    if (editingRental) {
      setClientId(editingRental.clientId);
      setSelectedAppId(editingRental.appId || 'custom');
      setCustomAppName(editingRental.appId ? '' : editingRental.appName);
      setPrice(String(editingRental.price));
      setBillingCycle(editingRental.billingCycle);
      setStartDate(editingRental.startDate);
      setEndDate(editingRental.endDate);
      setPaymentStatus(editingRental.paymentStatus);
      setAccountInfo(editingRental.accountInfo || '');
      setNotes(editingRental.notes || '');
      return;
    }

    const initialClient = defaultClientId || clients[0]?.id || '';
    const initialApp =
      (defaultAppId ? apps.find((a) => a.id === defaultAppId) : apps[0]) || null;
    const today = todayISO();

    setClientId(initialClient);
    setSelectedAppId(initialApp ? initialApp.id : 'custom');
    setCustomAppName('');
    setPrice(initialApp ? String(initialApp.monthlyPrice) : '');
    setBillingCycle('monthly');
    setStartDate(today);
    setEndDate(addMonthsToDate(today, 1));
    setPaymentStatus('paid');
    setAccountInfo('');
    setNotes('');
  }, [open, editingRental, defaultClientId, defaultAppId, clients, apps]);

  if (!open) return null;

  const handleSelectApp = (val: string) => {
    setSelectedAppId(val);
    const appObj = apps.find((a) => a.id === val);
    if (appObj) {
      setPrice(String(appObj.monthlyPrice));
    }
  };

  const handleCycleChange = (cycle: BillingCycle) => {
    setBillingCycle(cycle);
    if (cycle === 'monthly') {
      setEndDate(addMonthsToDate(startDate, 1));
    } else if (cycle === 'quarterly') {
      setEndDate(addMonthsToDate(startDate, 3));
    } else if (cycle === 'yearly') {
      setEndDate(addMonthsToDate(startDate, 12));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientId) {
      setError('يرجى اختيار العميل أولاً (أو إضافة عميل جديد).');
      return;
    }

    const chosenApp = apps.find((a) => a.id === selectedAppId);
    const resolvedAppName =
      selectedAppId === 'custom' ? customAppName.trim() : chosenApp?.name || '';

    if (!resolvedAppName) {
      setError('يرجى اختيار التطبيق أو كتابة اسمه.');
      return;
    }

    const numPrice = Number(price);
    if (Number.isNaN(numPrice) || numPrice < 0) {
      setError('يرجى إدخال سعر صحيح.');
      return;
    }

    const payload = {
      clientId,
      appId: selectedAppId === 'custom' ? undefined : chosenApp?.id,
      appName: resolvedAppName,
      price: numPrice,
      billingCycle,
      startDate,
      endDate,
      paymentStatus,
      accountInfo: accountInfo.trim() || undefined,
      notes: notes.trim() || undefined,
    };

    if (editingRental) {
      updateRental(editingRental.id, payload);
    } else {
      addRental(payload);
    }
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/55 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="flex max-h-[90vh] w-full max-w-lg flex-col rounded-t-3xl sm:rounded-2xl border border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-900"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto mt-3 h-1.5 w-10 rounded-full bg-slate-200 sm:hidden dark:bg-slate-700" />
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4 dark:border-slate-800">
          <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
            {editingRental ? 'تعديل اشتراك التطبيق' : 'إضافة تطبيق للعميل / تأجير جديد'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق"
            className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 space-y-4 overflow-y-auto p-5">
          {error && (
            <div className="rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs font-medium text-rose-700 dark:border-rose-800 dark:bg-rose-950/50 dark:text-rose-300">
              {error}
            </div>
          )}

          {!defaultClientId && (
            <label className="block">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                العميل
              </span>
              <select
                value={clientId}
                onChange={(e) => setClientId(e.target.value)}
                className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              >
                {clients.length === 0 && <option value="">لا يوجد عملاء بعد</option>}
                {clients.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} — {c.whatsapp}
                  </option>
                ))}
              </select>
            </label>
          )}

          <label className="block">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              اختر التطبيق
            </span>
            <select
              value={selectedAppId}
              onChange={(e) => handleSelectApp(e.target.value)}
              className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
            >
              {apps.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name} ({a.monthlyPrice} {settings.currency}/شهر)
                </option>
              ))}
              <option value="custom">+ كتابة اسم تطبيق آخر يدوياً</option>
            </select>
          </label>

          {selectedAppId === 'custom' && (
            <label className="block">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                اسم التطبيق
              </span>
              <input
                type="text"
                placeholder="مثال: تطبيق المبيعات السحابي"
                value={customAppName}
                onChange={(e) => setCustomAppName(e.target.value)}
                className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </label>
          )}

          <div className="grid grid-cols-2 gap-3">
            <label className="block">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                السعر ({settings.currency})
              </span>
              <input
                type="number"
                min={0}
                step="0.5"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="tabular-nums mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </label>

            <label className="block">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                دورة التأجير
              </span>
              <select
                value={billingCycle}
                onChange={(e) => handleCycleChange(e.target.value as BillingCycle)}
                className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              >
                <option value="monthly">شهري</option>
                <option value="quarterly">ربع سنوي (3 أشهر)</option>
                <option value="yearly">سنوي</option>
                <option value="custom">مخصص</option>
              </select>
            </label>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <label className="block">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                تاريخ البداية
              </span>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="tabular-nums mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </label>

            <label className="block">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                تاريخ الانتهاء
              </span>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="tabular-nums mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
              />
            </label>
          </div>

          <div>
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              حالة السداد
            </span>
            <div className="mt-1.5 grid grid-cols-3 gap-2 rounded-xl bg-slate-100 p-1 dark:bg-slate-800">
              {[
                { key: 'paid', label: 'تم السداد' },
                { key: 'pending', label: 'بانتظار الدفع' },
                { key: 'overdue', label: 'متأخر' },
              ].map((opt) => (
                <button
                  key={opt.key}
                  type="button"
                  onClick={() => setPaymentStatus(opt.key as PaymentStatus)}
                  className={`min-h-[38px] rounded-lg px-2 text-xs font-medium transition-colors ${
                    paymentStatus === opt.key
                      ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <label className="block">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              بيانات الجهاز أو الحساب (اختياري)
            </span>
            <input
              type="text"
              placeholder="مثال: حساب فرع 2 أو رقم الجهاز"
              value={accountInfo}
              onChange={(e) => setAccountInfo(e.target.value)}
              className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
            />
          </label>

          <label className="block">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              ملاحظات (اختياري)
            </span>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="أي شروط أو تفاصيل إضافية..."
              className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
            />
          </label>

          <div className="flex gap-2.5 pt-2">
            <button
              type="submit"
              className="flex h-12 flex-1 items-center justify-center rounded-xl bg-teal-700 text-sm font-semibold text-white hover:bg-teal-800 dark:bg-teal-600 dark:hover:bg-teal-500"
            >
              {editingRental ? 'حفظ التعديلات' : 'حفظ التأجير'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex h-12 items-center justify-center rounded-xl border border-slate-200 px-5 text-sm font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
