import React, { useMemo, useState } from 'react';
import { AppWindow, Edit3, Plus, Search, Trash2, X } from 'lucide-react';
import { useRentalStore } from '../store/useRentalStore';
import type { AppItem } from '../types/app';
import { ConfirmModal } from './ConfirmModal';

interface AppsViewProps {
  onRentApp: (appId: string) => void;
  externalOpenAddSignal?: number;
}

export const AppsView: React.FC<AppsViewProps> = ({ onRentApp, externalOpenAddSignal }) => {
  const { apps, rentals, settings, addApp, updateApp, deleteApp } = useRentalStore();
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('الكل');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingApp, setEditingApp] = useState<AppItem | null>(null);
  const [confirmDeleteApp, setConfirmDeleteApp] = useState<AppItem | null>(null);

  const [name, setName] = useState('');
  const [category, setCategory] = useState('أعمال ومبيعات');
  const [monthlyPrice, setMonthlyPrice] = useState('');
  const [totalSlots, setTotalSlots] = useState('10');
  const [description, setDescription] = useState('');

  React.useEffect(() => {
    if (externalOpenAddSignal && externalOpenAddSignal > 0) {
      openCreateModal();
    }
  }, [externalOpenAddSignal]);

  const categories = useMemo(() => {
    const set = new Set<string>(apps.map((a) => a.category).filter(Boolean));
    return ['الكل', ...Array.from(set)];
  }, [apps]);

  const filteredApps = useMemo(() => {
    return apps.filter((a) => {
      const matchesCat = selectedCategory === 'الكل' || a.category === selectedCategory;
      const q = search.trim().toLowerCase();
      const matchesSearch =
        !q ||
        a.name.toLowerCase().includes(q) ||
        a.category.toLowerCase().includes(q) ||
        (a.description || '').toLowerCase().includes(q);
      return matchesCat && matchesSearch;
    });
  }, [apps, selectedCategory, search]);

  const openCreateModal = () => {
    setEditingApp(null);
    setName('');
    setCategory('أعمال ومبيعات');
    setMonthlyPrice('');
    setTotalSlots('10');
    setDescription('');
    setModalOpen(true);
  };

  const openEditModal = (app: AppItem) => {
    setEditingApp(app);
    setName(app.name);
    setCategory(app.category);
    setMonthlyPrice(String(app.monthlyPrice));
    setTotalSlots(String(app.totalSlots));
    setDescription(app.description || '');
    setModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const payload = {
      name: name.trim(),
      category: category.trim() || 'عام',
      monthlyPrice: Math.max(0, Number(monthlyPrice) || 0),
      totalSlots: Math.max(1, Number(totalSlots) || 1),
      description: description.trim() || undefined,
    };
    if (editingApp) {
      updateApp(editingApp.id, payload);
    } else {
      addApp(payload);
    }
    setModalOpen(false);
  };

  return (
    <div className="space-y-4">
      {/* Header + Add */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
            قائمة التطبيقات المتاحة للتأجير
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            إدارة الأسعار والمقاعد والتأجير للعملاء
          </p>
        </div>
        <button
          type="button"
          onClick={openCreateModal}
          className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-teal-700 px-4 py-2 text-sm font-semibold text-white hover:bg-teal-800 whitespace-nowrap shrink-0 dark:bg-teal-600 dark:hover:bg-teal-500"
        >
          <Plus className="h-4 w-4" />
          <span>إضافة تطبيق</span>
        </button>
      </div>

      {/* Search + Category Filter Tabs */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث عن تطبيق..."
            className="h-11 w-full rounded-xl border border-slate-200 bg-white pr-10 pl-4 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-600 focus:outline-none dark:border-slate-800 dark:bg-slate-900 dark:text-white"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`min-h-[38px] rounded-lg px-3 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                selectedCategory === cat
                  ? 'bg-slate-900 text-white dark:bg-teal-600'
                  : 'border border-slate-200 bg-white text-slate-600 hover:text-slate-900 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Apps List */}
      {filteredApps.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center dark:border-slate-800 dark:bg-slate-900">
          <AppWindow className="mx-auto h-10 w-10 text-slate-400" />
          <p className="mt-3 text-sm font-semibold text-slate-900 dark:text-white">
            لا توجد تطبيقات مطابقة
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            أضف تطبيقاتك المتاحة للتأجير لتعيينها بسهولة للعملاء.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {filteredApps.map((app) => {
            const activeCount = rentals.filter(
              (r) => r.appId === app.id || r.appName === app.name
            ).length;
            return (
              <div
                key={app.id}
                className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900"
              >
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-teal-50 text-teal-700 dark:bg-teal-950/60 dark:text-teal-300">
                        <AppWindow className="h-5 w-5" />
                      </div>
                      <div className="min-w-0">
                        <h3 className="truncate text-sm font-bold text-slate-900 dark:text-white">
                          {app.name}
                        </h3>
                        <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                          {app.category} <span aria-hidden="true">·</span>{' '}
                          <span className="tabular-nums">
                            {activeCount} / {app.totalSlots} مستأجر
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="shrink-0 text-left">
                      <div className="tabular-nums font-display text-base font-bold text-teal-700 dark:text-teal-400">
                        {app.monthlyPrice} {settings.currency}
                      </div>
                      <div className="text-[11px] text-slate-400">شهرياً</div>
                    </div>
                  </div>

                  {app.description && (
                    <p className="mt-3 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
                      {app.description}
                    </p>
                  )}
                </div>

                <div className="mt-4 flex items-center justify-between gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => onRentApp(app.id)}
                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl bg-teal-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-teal-800 dark:bg-teal-600 dark:hover:bg-teal-500"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span>تأجير لعميل</span>
                  </button>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => openEditModal(app)}
                      aria-label={`تعديل ${app.name}`}
                      className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 hover:text-slate-800 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
                    >
                      <Edit3 className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteApp(app)}
                      aria-label={`حذف ${app.name}`}
                      className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-500 hover:bg-rose-50 hover:text-rose-600 dark:text-slate-400 dark:hover:bg-rose-950/40 dark:hover:text-rose-400"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit App Modal */}
      {modalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/55 backdrop-blur-xs"
          onClick={() => setModalOpen(false)}
        >
          <div
            className="w-full max-w-md rounded-t-3xl sm:rounded-2xl border border-slate-200 bg-white p-5 shadow-2xl dark:border-slate-800 dark:bg-slate-900"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <h3 className="font-display text-base font-bold text-slate-900 dark:text-white">
                {editingApp ? 'تعديل التطبيق' : 'إضافة تطبيق جديد'}
              </h3>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                aria-label="إغلاق"
                className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="mt-4 space-y-3.5">
              <label className="block">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  اسم التطبيق
                </span>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="مثال: تطبيق إدارة المتجر"
                  className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </label>

              <label className="block">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  التصنيف
                </span>
                <input
                  type="text"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  placeholder="مثال: أعمال ومبيعات"
                  className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </label>

              <div className="grid grid-cols-2 gap-3">
                <label className="block">
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    سعر التأجير ({settings.currency}/شهر)
                  </span>
                  <input
                    type="number"
                    required
                    min={0}
                    step="0.5"
                    value={monthlyPrice}
                    onChange={(e) => setMonthlyPrice(e.target.value)}
                    className="tabular-nums mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </label>

                <label className="block">
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    عدد المقاعد المتاحة
                  </span>
                  <input
                    type="number"
                    min={1}
                    value={totalSlots}
                    onChange={(e) => setTotalSlots(e.target.value)}
                    className="tabular-nums mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </label>
              </div>

              <label className="block">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  وصف مختصر (اختياري)
                </span>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </label>

              <div className="flex gap-2.5 pt-2">
                <button
                  type="submit"
                  className="flex h-11 flex-1 items-center justify-center rounded-xl bg-teal-700 text-sm font-semibold text-white hover:bg-teal-800 dark:bg-teal-600"
                >
                  حفظ التطبيق
                </button>
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="flex h-11 items-center justify-center rounded-xl border border-slate-200 px-5 text-sm font-medium text-slate-700 dark:border-slate-700 dark:text-slate-300"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal
        open={!!confirmDeleteApp}
        title="حذف التطبيق"
        message={`هل تريد حذف «${confirmDeleteApp?.name ?? ''}» من قائمة التطبيقات؟`}
        onCancel={() => setConfirmDeleteApp(null)}
        onConfirm={() => {
          if (confirmDeleteApp) deleteApp(confirmDeleteApp.id);
          setConfirmDeleteApp(null);
        }}
      />
    </div>
  );
};
