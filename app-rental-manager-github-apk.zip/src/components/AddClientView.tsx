import React, { useEffect, useRef, useState } from 'react';
import { Camera, Trash2 } from 'lucide-react';
import { useRentalStore } from '../store/useRentalStore';
import { compressImageToDataUrl } from '../utils/helpers';
import { ClientAvatar } from './ClientAvatar';

interface AddClientViewProps {
  editClientId?: string;
  onDone: (clientId?: string) => void;
  onCancel: () => void;
}

export const AddClientView: React.FC<AddClientViewProps> = ({
  editClientId,
  onDone,
  onCancel,
}) => {
  const { clients, addClient, updateClient } = useRentalStore();
  const existing = editClientId ? clients.find((c) => c.id === editClientId) : undefined;

  const [name, setName] = useState(existing?.name ?? '');
  const [whatsapp, setWhatsapp] = useState(existing?.whatsapp ?? '');
  const [extraContact, setExtraContact] = useState(existing?.extraContact ?? '');
  const [notes, setNotes] = useState(existing?.notes ?? '');
  const [avatarDataUrl, setAvatarDataUrl] = useState<string | undefined>(
    existing?.avatarDataUrl
  );
  const [error, setError] = useState('');
  const [isUploading, setIsUploading] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (existing) {
      setName(existing.name);
      setWhatsapp(existing.whatsapp);
      setExtraContact(existing.extraContact || '');
      setNotes(existing.notes);
      setAvatarDataUrl(existing.avatarDataUrl);
    }
  }, [existing]);

  const handlePhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploading(true);
    setError('');
    try {
      const compressed = await compressImageToDataUrl(file, 420, 0.8);
      setAvatarDataUrl(compressed);
    } catch {
      setError('تعذر معالجة الصورة المختارة، جرب صورة أخرى.');
    } finally {
      setIsUploading(false);
      e.target.value = '';
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('يرجى إدخال اسم العميل.');
      return;
    }
    if (!whatsapp.trim()) {
      setError('يرجى إدخال رقم واتساب العميل.');
      return;
    }

    if (existing) {
      updateClient(existing.id, {
        name: name.trim(),
        whatsapp: whatsapp.trim(),
        extraContact: extraContact.trim() || undefined,
        notes: notes.trim(),
        avatarDataUrl,
      });
      onDone(existing.id);
    } else {
      const created = addClient({
        name: name.trim(),
        whatsapp: whatsapp.trim(),
        extraContact: extraContact.trim() || undefined,
        notes: notes.trim(),
        avatarDataUrl,
      });
      onDone(created.id);
    }
  };

  return (
    <div className="mx-auto max-w-xl">
      <form
        onSubmit={handleSubmit}
        className="space-y-5 rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 dark:border-slate-800 dark:bg-slate-900"
      >
        <div className="border-b border-slate-100 pb-3 dark:border-slate-800">
          <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
            {existing ? 'تعديل بيانات العميل' : 'إضافة عميل جديد'}
          </h2>
          <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
            صورة العميل، رقم التواصل، والملاحظات الخاصة
          </p>
        </div>

        {error && (
          <div className="rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs font-medium text-rose-700 dark:border-rose-800 dark:bg-rose-950/50 dark:text-rose-300">
            {error}
          </div>
        )}

        {/* Client Photo Section */}
        <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-slate-50/70 p-5 dark:border-slate-700 dark:bg-slate-800/40">
          <ClientAvatar name={name || 'عميل'} src={avatarDataUrl} size="xl" />

          <div className="mt-3.5 flex flex-wrap items-center justify-center gap-2">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="inline-flex min-h-[42px] items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-teal-600 dark:hover:bg-teal-500"
            >
              <Camera className="h-4 w-4" />
              <span>{isUploading ? 'جاري التحميل...' : avatarDataUrl ? 'تغيير الصورة' : 'اختيار صورة العميل'}</span>
            </button>

            {avatarDataUrl && (
              <button
                type="button"
                onClick={() => setAvatarDataUrl(undefined)}
                className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl border border-rose-200 bg-white px-3 py-2 text-xs font-medium text-rose-700 hover:bg-rose-50 dark:border-rose-900 dark:bg-slate-900 dark:text-rose-400"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>إزالة</span>
              </button>
            )}
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handlePhotoChange}
            className="hidden"
          />
        </div>

        {/* Name */}
        <label className="block">
          <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
            اسم العميل
          </span>
          <input
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="مثال: محمد العلي"
            className="mt-1.5 h-12 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
          />
        </label>

        {/* WhatsApp / Phone */}
        <label className="block">
          <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
            رقم الواتساب / الهاتف
          </span>
          <input
            type="tel"
            required
            dir="ltr"
            value={whatsapp}
            onChange={(e) => setWhatsapp(e.target.value)}
            placeholder="966501234567"
            className="tabular-nums mt-1.5 h-12 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-left text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
          />
          <span className="mt-1 block text-[11px] text-slate-500 dark:text-slate-400">
            يفضل كتابة الرقم مع رمز الدولة لتعمل روابط واتساب مباشرة (مثال: 9665...).
          </span>
        </label>

        {/* Extra Contact */}
        <label className="block">
          <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
            تواصل إضافي (اختياري)
          </span>
          <input
            type="text"
            value={extraContact}
            onChange={(e) => setExtraContact(e.target.value)}
            placeholder="رقم آخر، بريد إلكتروني، أو حساب تيليجرام"
            className="mt-1.5 h-12 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
          />
        </label>

        {/* Notes */}
        <label className="block">
          <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
            ملاحظات
          </span>
          <textarea
            rows={3}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="اكتب أي ملاحظات عن العميل أو طريقة الدفع المفضلة..."
            className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 p-3.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
          />
        </label>

        {/* Submit / Cancel */}
        <div className="flex gap-3 pt-2">
          <button
            type="submit"
            className="flex h-12 flex-1 items-center justify-center rounded-xl bg-teal-700 text-sm font-semibold text-white hover:bg-teal-800 dark:bg-teal-600 dark:hover:bg-teal-500"
          >
            {existing ? 'حفظ التعديلات' : 'حفظ العميل'}
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="flex h-12 items-center justify-center rounded-xl border border-slate-200 px-6 text-sm font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
          >
            إلغاء
          </button>
        </div>
      </form>
    </div>
  );
};
