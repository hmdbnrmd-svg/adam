import React, { useEffect, useMemo, useState } from 'react';
import { Plus, Star, Trash2, X } from 'lucide-react';
import { useRentalStore } from '../store/useRentalStore';
import type { CommitmentTag } from '../types/app';
import { formatArabicDate } from '../utils/helpers';
import { ClientAvatar } from './ClientAvatar';

interface RatingsViewProps {
  onOpenClient: (clientId: string) => void;
  externalOpenAddSignal?: number;
}

export const RatingsView: React.FC<RatingsViewProps> = ({
  onOpenClient,
  externalOpenAddSignal,
}) => {
  const { ratings, clients, apps, addRating, deleteRating } = useRentalStore();
  const [filterTag, setFilterTag] = useState<'الكل' | CommitmentTag>('الكل');
  const [modalOpen, setModalOpen] = useState(false);

  const [clientId, setClientId] = useState('');
  const [appName, setAppName] = useState('');
  const [score, setScore] = useState(5);
  const [commitmentTag, setCommitmentTag] = useState<CommitmentTag>('ملتزم');
  const [comment, setComment] = useState('');

  useEffect(() => {
    if (externalOpenAddSignal && externalOpenAddSignal > 0) {
      openModal();
    }
  }, [externalOpenAddSignal]);

  const openModal = () => {
    setClientId(clients[0]?.id || '');
    setAppName(apps[0]?.name || '');
    setScore(5);
    setCommitmentTag('ملتزم');
    setComment('');
    setModalOpen(true);
  };

  const clientMap = new Map(clients.map((c) => [c.id, c]));

  const filteredRatings = useMemo(() => {
    if (filterTag === 'الكل') return ratings;
    return ratings.filter((r) => r.commitmentTag === filterTag);
  }, [ratings, filterTag]);

  const avgScore = useMemo(() => {
    if (ratings.length === 0) return 0;
    const sum = ratings.reduce((acc, r) => acc + r.score, 0);
    return (sum / ratings.length).toFixed(1);
  }, [ratings]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientId) return;
    addRating({
      clientId,
      appName: appName.trim() || 'تأجير عام',
      score,
      commitmentTag,
      comment: comment.trim(),
    });
    setModalOpen(false);
  };

  return (
    <div className="space-y-4">
      {/* Header + Summary */}
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
            تقييمات العملاء والتأجير
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            متوسط التقييم: <span className="tabular-nums font-bold">{avgScore}</span> / 5{' '}
            <span aria-hidden="true">·</span>{' '}
            <span className="tabular-nums">{ratings.length}</span> تقييم
          </p>
        </div>

        <button
          type="button"
          onClick={openModal}
          className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-teal-700 px-4 py-2 text-sm font-semibold text-white hover:bg-teal-800 whitespace-nowrap shrink-0 dark:bg-teal-600 dark:hover:bg-teal-500"
        >
          <Plus className="h-4 w-4" />
          <span>إضافة تقييم</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {(['الكل', 'ملتزم', 'تأخير بسيط', 'يحتاج متابعة'] as const).map((tag) => (
          <button
            key={tag}
            type="button"
            onClick={() => setFilterTag(tag)}
            className={`min-h-[38px] rounded-lg px-3 py-1.5 text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
              filterTag === tag
                ? 'bg-slate-900 text-white dark:bg-teal-600'
                : 'border border-slate-200 bg-white text-slate-600 hover:text-slate-900 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300'
            }`}
          >
            {tag}
          </button>
        ))}
      </div>

      {/* Ratings List */}
      {filteredRatings.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center dark:border-slate-800 dark:bg-slate-900">
          <Star className="mx-auto h-10 w-10 text-slate-400" />
          <p className="mt-3 text-sm font-semibold text-slate-900 dark:text-white">
            لا توجد تقييمات مسجلة في هذا التصنيف
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {filteredRatings.map((rating) => {
            const client = clientMap.get(rating.clientId);
            return (
              <div
                key={rating.id}
                className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900"
              >
                <div className="flex items-start justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => client && onOpenClient(client.id)}
                    className="flex min-w-0 items-center gap-3 text-right"
                  >
                    <ClientAvatar
                      name={client?.name || 'عميل'}
                      src={client?.avatarDataUrl}
                      size="sm"
                    />
                    <div className="min-w-0">
                      <div className="truncate text-sm font-bold text-slate-900 dark:text-white">
                        {client?.name || 'عميل محذوف'}
                      </div>
                      <div className="truncate text-xs text-slate-500 dark:text-slate-400">
                        {rating.appName} <span aria-hidden="true">·</span>{' '}
                        <span className="tabular-nums">{formatArabicDate(rating.createdAt)}</span>
                      </div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => deleteRating(rating.id)}
                    aria-label="حذف التقييم"
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/40"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>

                <div className="mt-3 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-0.5" aria-label={`التقييم ${rating.score} من 5`}>
                    {[1, 2, 3, 4, 5].map((n) => (
                      <Star
                        key={n}
                        className={`h-4 w-4 ${
                          n <= rating.score
                            ? 'fill-amber-400 text-amber-400'
                            : 'text-slate-300 dark:text-slate-700'
                        }`}
                      />
                    ))}
                  </div>

                  <span
                    className={`text-xs font-semibold ${
                      rating.commitmentTag === 'ملتزم'
                        ? 'text-teal-700 dark:text-teal-400'
                        : rating.commitmentTag === 'تأخير بسيط'
                        ? 'text-amber-700 dark:text-amber-400'
                        : 'text-rose-700 dark:text-rose-400'
                    }`}
                  >
                    {rating.commitmentTag}
                  </span>
                </div>

                {rating.comment && (
                  <p className="mt-2.5 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
                    {rating.comment}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Add Rating Modal */}
      {modalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/55 backdrop-blur-xs"
          onClick={() => setModalOpen(false)}
        >
          <div
            className="w-full max-w-md rounded-t-3xl sm:rounded-2xl border border-slate-200 bg-white p-5 shadow-2xl dark:border-slate-800 dark:bg-slate-900"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <h3 className="font-display text-base font-bold text-slate-900 dark:text-white">
                إضافة تقييم جديد
              </h3>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                aria-label="إغلاق"
                className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5">
              <label className="block">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  العميل
                </span>
                <select
                  value={clientId}
                  onChange={(e) => setClientId(e.target.value)}
                  required
                  className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                >
                  {clients.length === 0 && <option value="">لا يوجد عملاء</option>}
                  {clients.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </label>

              <label className="block">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  التطبيق
                </span>
                <input
                  type="text"
                  value={appName}
                  onChange={(e) => setAppName(e.target.value)}
                  placeholder="اسم التطبيق المؤجر"
                  className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </label>

              <div>
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  التقييم بالنجوم
                </span>
                <div className="mt-1.5 flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => setScore(n)}
                      className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700"
                    >
                      <Star
                        className={`h-5 w-5 ${
                          n <= score
                            ? 'fill-amber-400 text-amber-400'
                            : 'text-slate-300 dark:text-slate-600'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  حالة الالتزام
                </span>
                <div className="mt-1.5 grid grid-cols-3 gap-2 rounded-xl bg-slate-100 p-1 dark:bg-slate-800">
                  {(['ملتزم', 'تأخير بسيط', 'يحتاج متابعة'] as const).map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setCommitmentTag(t)}
                      className={`min-h-[38px] rounded-lg px-2 text-xs font-medium ${
                        commitmentTag === t
                          ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              <label className="block">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  ملاحظات التقييم
                </span>
                <textarea
                  rows={2}
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="اكتب ملاحظتك حول التزام العميل أو تجربة التطبيق..."
                  className="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 p-3 text-sm text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </label>

              <div className="flex gap-2.5 pt-2">
                <button
                  type="submit"
                  disabled={!clientId}
                  className="flex h-11 flex-1 items-center justify-center rounded-xl bg-teal-700 text-sm font-semibold text-white hover:bg-teal-800 disabled:opacity-50 dark:bg-teal-600"
                >
                  حفظ التقييم
                </button>
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="flex h-11 items-center justify-center rounded-xl border border-slate-200 px-5 text-sm font-medium text-slate-700 dark:border-slate-700 dark:text-slate-300"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
