import React from 'react';
import { getInitials } from '../utils/helpers';

interface ClientAvatarProps {
  name: string;
  src?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const sizeClasses: Record<NonNullable<ClientAvatarProps['size']>, string> = {
  sm: 'h-10 w-10 text-xs',
  md: 'h-12 w-12 text-sm',
  lg: 'h-16 w-16 text-lg',
  xl: 'h-28 w-28 text-2xl',
};

export const ClientAvatar: React.FC<ClientAvatarProps> = ({
  name,
  src,
  size = 'md',
  className = '',
}) => {
  if (src) {
    return (
      <img
        src={src}
        alt={name}
        referrerPolicy="no-referrer"
        className={`${sizeClasses[size]} shrink-0 rounded-2xl border border-slate-200 object-cover bg-slate-100 dark:border-slate-700 dark:bg-slate-800 ${className}`}
      />
    );
  }

  return (
    <div
      aria-label={name}
      className={`${sizeClasses[size]} shrink-0 flex items-center justify-center rounded-2xl border border-teal-200 bg-teal-50 font-display font-bold text-teal-800 dark:border-teal-800/60 dark:bg-teal-950/70 dark:text-teal-200 ${className}`}
    >
      {getInitials(name)}
    </div>
  );
};
