import React, { useMemo, useState } from 'react';
import { ChevronLeft, MessageCircle, Phone, Search, UserPlus, Users } from 'lucide-react';
import { useRentalStore } from '../store/useRentalStore';
import { formatWhatsAppUrl } from '../utils/helpers';
import { ClientAvatar } from './ClientAvatar';

interface ClientsViewProps {
  onAddClient: () => void;
  onOpenClientDetails: (clientId: string) => void;
}

export const ClientsView: React.FC<ClientsViewProps> = ({
  onAddClient,
  onOpenClientDetails,
}) => {
  const { clients, rentals } = useRentalStore();
  const [search, setSearch] = useState('');

  const filteredClients = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return clients;
    return clients.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.whatsapp.toLowerCase().includes(q) ||
        (c.extraContact || '').toLowerCase().includes(q)
    );
  }, [clients, search]);

  return (
    <div className="space-y-4">
      {/* Header + Add Client */}
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
            العملاء
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            <span className="tabular-nums">{clients.length}</span> عميل مسجل
          </p>
        </div>

        <button
          type="button"
          onClick={onAddClient}
          className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-teal-700 px-4 py-2 text-sm font-semibold text-white hover:bg-teal-800 whitespace-nowrap shrink-0 dark:bg-teal-600 dark:hover:bg-teal-500"
        >
          <UserPlus className="h-4 w-4" />
          <span>إضافة عميل</span>
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <input
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="ابحث باسم العميل أو رقم الواتساب..."
          className="h-11 w-full rounded-xl border border-slate-200 bg-white pr-10 pl-4 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-600 focus:outline-none dark:border-slate-800 dark:bg-slate-900 dark:text-white"
        />
      </div>

      {/* Clients Rectangular List */}
      {filteredClients.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center dark:border-slate-800 dark:bg-slate-900">
          <Users className="mx-auto h-10 w-10 text-slate-400" />
          <p className="mt-3 text-sm font-semibold text-slate-900 dark:text-white">
            {clients.length === 0 ? 'لا يوجد عملاء حتى الآن' : 'لا توجد نتائج مطابقة'}
          </p>
          {clients.length === 0 && (
            <button
              type="button"
              onClick={onAddClient}
              className="mt-4 inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-teal-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-teal-800 dark:bg-teal-600"
            >
              <UserPlus className="h-4 w-4" />
              <span>إضافة أول عميل</span>
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {filteredClients.map((client) => {
            const clientRentalsCount = rentals.filter((r) => r.clientId === client.id).length;

            return (
              <div
                key={client.id}
                className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-4 transition-colors hover:border-teal-500/40 dark:border-slate-800 dark:bg-slate-900"
              >
                {/* Top Rectangular Row: Avatar + Name + WhatsApp + Extra Contact */}
                <div className="flex items-start gap-3.5">
                  <button
                    type="button"
                    onClick={() => onOpenClientDetails(client.id)}
                    className="shrink-0"
                  >
                    <ClientAvatar name={client.name} src={client.avatarDataUrl} size="lg" />
                  </button>

                  <div className="min-w-0 flex-1">
                    <button
                      type="button"
                      onClick={() => onOpenClientDetails(client.id)}
                      className="block w-full text-right"
                    >
                      <h3 className="truncate font-display text-base font-bold text-slate-900 dark:text-white">
                        {client.name}
                      </h3>
                    </button>

                    <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-600 dark:text-slate-300">
                      <span className="tabular-nums font-mono" dir="ltr">
                        {client.whatsapp}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums text-slate-500 dark:text-slate-400">
                        {clientRentalsCount} {clientRentalsCount === 1 ? 'تطبيق' : 'تطبيقات'}
                      </span>
                    </div>

                    {client.extraContact && (
                      <div className="mt-1.5 flex items-center gap-1.5 truncate text-xs text-slate-500 dark:text-slate-400">
                        <Phone className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                        <span className="truncate">{client.extraContact}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Bottom Actions inside Rectangle: WhatsApp direct + Client Details */}
                <div className="mt-3.5 flex items-center justify-between gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
                  <a
                    href={formatWhatsAppUrl(client.whatsapp)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50/70 px-3 py-1.5 text-xs font-semibold text-emerald-800 hover:bg-emerald-100 dark:border-emerald-800/60 dark:bg-emerald-950/40 dark:text-emerald-300"
                  >
                    <MessageCircle className="h-4 w-4" />
                    <span>واتساب</span>
                  </a>

                  <button
                    type="button"
                    onClick={() => onOpenClientDetails(client.id)}
                    className="inline-flex min-h-[40px] items-center gap-1 rounded-xl bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700"
                  >
                    <span>تفاصيل العميل</span>
                    <ChevronLeft className="h-4 w-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
