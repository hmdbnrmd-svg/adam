import React, { useState } from 'react';
import { CheckCircle2, Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  variant?: 'primary' | 'compact' | 'card';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ variant = 'primary' }) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  if (isInstalled) {
    if (variant === 'card') {
      return (
        <div className="flex items-center gap-3 rounded-xl border border-teal-200 bg-teal-50/70 p-3.5 text-sm text-teal-900 dark:border-teal-800/60 dark:bg-teal-950/40 dark:text-teal-200">
          <CheckCircle2 className="h-5 w-5 shrink-0 text-teal-600 dark:text-teal-400" />
          <span>التطبيق مثبّت ويعمل بوضع التطبيق المستقل بدون متصفح.</span>
        </div>
      );
    }
    return null;
  }

  const handleAction = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (!accepted) return;
    } else {
      setShowGuide(true);
    }
  };

  return (
    <>
      {variant === 'card' ? (
        <button
          type="button"
          onClick={handleAction}
          className="flex w-full items-center justify-between gap-3 rounded-xl bg-teal-700 px-4 py-3 text-right text-white transition-colors hover:bg-teal-800 active:scale-[0.99] dark:bg-teal-600 dark:hover:bg-teal-500"
        >
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-white/15">
              <Smartphone className="h-5 w-5" />
            </div>
            <div>
              <div className="text-sm font-semibold">تثبيت التطبيق على الجهاز</div>
              <div className="text-xs text-teal-100">
                {isInstallable
                  ? 'جاهز للتثبيت المباشر كتطبيق مستقل (بدون متجر)'
                  : 'تثبيت دائم على الشاشة الرئيسية والعمل دون إنترنت'}
              </div>
            </div>
          </div>
          <Download className="h-5 w-5 shrink-0" />
        </button>
      ) : (
        <button
          type="button"
          onClick={handleAction}
          className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-teal-700 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-teal-800 whitespace-nowrap shrink-0 dark:bg-teal-600 dark:hover:bg-teal-500"
        >
          <Download className="h-4 w-4 shrink-0" />
          <span>تثبيت التطبيق</span>
        </button>
      )}

      {showGuide && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/60 p-0 sm:p-4 backdrop-blur-xs"
          onClick={() => setShowGuide(false)}
        >
          <div
            className="w-full max-w-md rounded-t-3xl sm:rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between gap-4 border-b border-slate-100 pb-4 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <Smartphone className="h-5 w-5 text-teal-600 dark:text-teal-400" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  تثبيت التطبيق على هاتفك (بدون جوجل بلاي)
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                aria-label="إغلاق"
                className="flex h-11 w-11 items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3 text-sm leading-relaxed text-slate-700 dark:text-slate-300">
              {isIOS ? (
                <ol className="list-decimal space-y-2 pr-5">
                  <li>افتح رابط التطبيق في متصفح <strong>Safari</strong>.</li>
                  <li>اضغط على زر <strong>المشاركة (Share)</strong> أسفل الشاشة.</li>
                  <li>اختر <strong>إضافة إلى الشاشة الرئيسية (Add to Home Screen)</strong>.</li>
                  <li>اضغط <strong>إضافة</strong> وسيظهر كأيقونة تطبيق مستقل تماماً.</li>
                </ol>
              ) : (
                <ol className="list-decimal space-y-2 pr-5">
                  <li>
                    افتح رابط التطبيق مباشرة في متصفح <strong>Chrome</strong> على هاتفك الأندرويد{isAndroid ? '' : ' (وليس داخل نافذة المعاينة)'}.
                  </li>
                  <li>اضغط على قائمة النقاط الثلاث <strong>(⋮)</strong> في أعلى المتصفح.</li>
                  <li>
                    اختر <strong>تثبيت التطبيق (Install app)</strong> أو <strong>الإضافة إلى الشاشة الرئيسية</strong>.
                  </li>
                  <li>
                    سيقوم نظام أندرويد بإنشاء حزمة تطبيق محلية (<strong>WebAPK</strong>) تثبت مباشرة في قائمة التطبيقات وتعمل بدون إنترنت وبدون نشر في المتجر.
                  </li>
                </ol>
              )}
            </div>

            <button
              type="button"
              onClick={() => setShowGuide(false)}
              className="mt-6 flex h-11 w-full items-center justify-center rounded-xl bg-slate-900 text-sm font-medium text-white hover:bg-slate-800 dark:bg-teal-600 dark:hover:bg-teal-500"
            >
              فهمت، إغلاق
            </button>
          </div>
        </div>
      )}
    </>
  );
};
