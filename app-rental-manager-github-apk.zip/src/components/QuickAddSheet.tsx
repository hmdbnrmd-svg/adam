import React from 'react';
import { AppWindow, FilePlus2, Star, UserPlus, X } from 'lucide-react';

interface QuickAddSheetProps {
  open: boolean;
  onClose: () => void;
  onAddClient: () => void;
  onAddRental: () => void;
  onAddApp: () => void;
  onAddRating: () => void;
}

export const QuickAddSheet: React.FC<QuickAddSheetProps> = ({
  open,
  onClose,
  onAddClient,
  onAddRental,
  onAddApp,
  onAddRating,
}) => {
  if (!open) return null;

  const actions = [
    {
      label: 'تأجير تطبيق لعميل',
      sub: 'تسجيل اشتراك جديد وتحديد موعد التجديد والسعر',
      icon: FilePlus2,
      onClick: () => {
        onClose();
        onAddRental();
      },
    },
    {
      label: 'إضافة عميل جديد',
      sub: 'حفظ اسم العميل وصورته ورقم الواتساب والملاحظات',
      icon: UserPlus,
      onClick: () => {
        onClose();
        onAddClient();
      },
    },
    {
      label: 'إضافة تطبيق للقائمة',
      sub: 'إضافة تطبيق أو باقة جديدة متاحة للتأجير',
      icon: AppWindow,
      onClick: () => {
        onClose();
        onAddApp();
      },
    },
    {
      label: 'إضافة تقييم',
      sub: 'تسجيل تقييم التزام العميل أو ملاحظة على التأجير',
      icon: Star,
      onClick: () => {
        onClose();
        onAddRating();
      },
    },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/55 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-t-3xl sm:rounded-2xl border border-slate-200 bg-white p-5 pb-safe shadow-2xl dark:border-slate-800 dark:bg-slate-900"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto mb-3 h-1.5 w-10 rounded-full bg-slate-200 sm:hidden dark:bg-slate-700" />
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
          <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
            إضافة سريعة
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق"
            className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="mt-3 space-y-2">
          {actions.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.label}
                type="button"
                onClick={item.onClick}
                className="flex w-full items-center gap-3.5 rounded-xl border border-slate-200 bg-slate-50/70 p-3.5 text-right transition-colors hover:border-teal-500/40 hover:bg-teal-50/60 active:scale-[0.99] dark:border-slate-800 dark:bg-slate-800/50 dark:hover:border-teal-500/40 dark:hover:bg-teal-950/30"
              >
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-teal-700 text-white dark:bg-teal-600">
                  <Icon className="h-5 w-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-semibold text-slate-900 dark:text-white">
                    {item.label}
                  </div>
                  <div className="mt-0.5 truncate text-xs text-slate-500 dark:text-slate-400">
                    {item.sub}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
