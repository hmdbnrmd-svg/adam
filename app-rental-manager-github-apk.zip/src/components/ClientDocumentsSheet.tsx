import React, { useRef, useState } from 'react';
import { Download, FileText, Image as ImageIcon, Plus, Trash2, Upload, X } from 'lucide-react';
import { useRentalStore } from '../store/useRentalStore';
import type { Client } from '../types/app';
import { compressImageToDataUrl, formatArabicDate, readFileAsDataUrl } from '../utils/helpers';

interface ClientDocumentsSheetProps {
  open: boolean;
  client: Client;
  onClose: () => void;
}

export const ClientDocumentsSheet: React.FC<ClientDocumentsSheetProps> = ({
  open,
  client,
  onClose,
}) => {
  const { addClientDocument, deleteClientDocument } = useRentalStore();
  const [docTitle, setDocTitle] = useState('');
  const [docMode, setDocMode] = useState<'file' | 'note'>('file');
  const [noteText, setNoteText] = useState('');
  const [previewDataUrl, setPreviewDataUrl] = useState<string | null>(null);
  const [previewTitle, setPreviewTitle] = useState('');
  const [error, setError] = useState('');
  const [isBusy, setIsBusy] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!open) return null;

  const handleFilePick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError('');
    setIsBusy(true);

    try {
      const title = docTitle.trim() || file.name.replace(/\.[^.]+$/, '');
      if (file.type.startsWith('image/')) {
        const compressed = await compressImageToDataUrl(file, 960, 0.8);
        addClientDocument(client.id, {
          title,
          type: 'image',
          dataUrl: compressed,
          fileName: file.name,
        });
      } else {
        if (file.size > 2.5 * 1024 * 1024) {
          setError('حجم الملف كبير جداً للتخزين المحلي (الحد الأقصى 2.5 ميجابايت).');
          setIsBusy(false);
          e.target.value = '';
          return;
        }
        const dataUrl = await readFileAsDataUrl(file);
        addClientDocument(client.id, {
          title,
          type: 'file',
          dataUrl,
          fileName: file.name,
        });
      }
      setDocTitle('');
    } catch {
      setError('تعذر حفظ المستند.');
    } finally {
      setIsBusy(false);
      e.target.value = '';
    }
  };

  const handleAddNoteDoc = (e: React.FormEvent) => {
    e.preventDefault();
    if (!docTitle.trim() || !noteText.trim()) {
      setError('يرجى إدخال عنوان المستند ونص الملاحظة.');
      return;
    }
    addClientDocument(client.id, {
      title: docTitle.trim(),
      type: 'note',
      noteText: noteText.trim(),
    });
    setDocTitle('');
    setNoteText('');
    setError('');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/60 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="flex max-h-[88vh] w-full max-w-lg flex-col rounded-t-3xl sm:rounded-2xl border border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-900"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto mt-3 h-1.5 w-10 rounded-full bg-slate-200 sm:hidden dark:bg-slate-700" />
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4 dark:border-slate-800">
          <div>
            <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
              مستندات العميل — {client.name}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              <span className="tabular-nums">{client.documents.length}</span> مستند محفوظ محلياً
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق"
            className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto p-5">
          {/* Add Document Area */}
          <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-4 dark:border-slate-800 dark:bg-slate-800/40">
            <div className="mb-3 flex gap-1.5 rounded-lg bg-slate-200/70 p-1 dark:bg-slate-800">
              <button
                type="button"
                onClick={() => setDocMode('file')}
                className={`flex-1 rounded-md py-1.5 text-xs font-semibold transition-colors ${
                  docMode === 'file'
                    ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                رفع صورة أو ملف
              </button>
              <button
                type="button"
                onClick={() => setDocMode('note')}
                className={`flex-1 rounded-md py-1.5 text-xs font-semibold transition-colors ${
                  docMode === 'note'
                    ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                وثيقة / اتفاق نصي
              </button>
            </div>

            {error && (
              <p className="mb-2 text-xs font-medium text-rose-600 dark:text-rose-400">
                {error}
              </p>
            )}

            <input
              type="text"
              value={docTitle}
              onChange={(e) => setDocTitle(e.target.value)}
              placeholder="عنوان المستند (مثال: إيصال تحويل، صورة الهوية، عقد)"
              className="mb-2.5 h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-xs text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-white"
            />

            {docMode === 'file' ? (
              <>
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() => fileInputRef.current?.click()}
                  className="flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-teal-700 text-xs font-semibold text-white hover:bg-teal-800 dark:bg-teal-600"
                >
                  <Upload className="h-4 w-4" />
                  <span>{isBusy ? 'جاري الحفظ...' : 'اختيار صورة أو ملف PDF'}</span>
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*,application/pdf,.doc,.docx,.txt"
                  onChange={handleFilePick}
                  className="hidden"
                />
              </>
            ) : (
              <form onSubmit={handleAddNoteDoc} className="space-y-2.5">
                <textarea
                  rows={2}
                  value={noteText}
                  onChange={(e) => setNoteText(e.target.value)}
                  placeholder="تفاصيل العقد أو الاتفاقية..."
                  className="w-full rounded-lg border border-slate-200 bg-white p-2.5 text-xs text-slate-900 focus:border-teal-600 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                />
                <button
                  type="submit"
                  className="flex h-10 w-full items-center justify-center gap-1.5 rounded-xl bg-teal-700 text-xs font-semibold text-white hover:bg-teal-800 dark:bg-teal-600"
                >
                  <Plus className="h-4 w-4" />
                  <span>حفظ الوثيقة</span>
                </button>
              </form>
            )}
          </div>

          {/* Documents List */}
          {client.documents.length === 0 ? (
            <p className="py-6 text-center text-xs text-slate-500 dark:text-slate-400">
              لا توجد مستندات مضافة لهذا العميل بعد.
            </p>
          ) : (
            <div className="space-y-2.5">
              {client.documents.map((doc) => (
                <div
                  key={doc.id}
                  className="flex items-start justify-between gap-3 rounded-xl border border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900"
                >
                  <div className="flex min-w-0 flex-1 items-start gap-3">
                    {doc.type === 'image' && doc.dataUrl ? (
                      <button
                        type="button"
                        onClick={() => {
                          setPreviewDataUrl(doc.dataUrl!);
                          setPreviewTitle(doc.title);
                        }}
                        className="h-12 w-12 shrink-0 overflow-hidden rounded-lg border border-slate-200 dark:border-slate-700"
                      >
                        <img
                          src={doc.dataUrl}
                          alt={doc.title}
                          referrerPolicy="no-referrer"
                          className="h-full w-full object-cover"
                        />
                      </button>
                    ) : (
                      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                        {doc.type === 'image' ? (
                          <ImageIcon className="h-5 w-5" />
                        ) : (
                          <FileText className="h-5 w-5" />
                        )}
                      </div>
                    )}

                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-semibold text-slate-900 dark:text-white">
                        {doc.title}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        <span className="tabular-nums">{formatArabicDate(doc.addedAt)}</span>
                        {doc.fileName ? ` · ${doc.fileName}` : ''}
                      </div>
                      {doc.noteText && (
                        <p className="mt-1.5 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
                          {doc.noteText}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex shrink-0 items-center gap-1">
                    {doc.dataUrl && (
                      <a
                        href={doc.dataUrl}
                        download={doc.fileName || `${doc.title}.jpg`}
                        aria-label="تحميل"
                        className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-800 dark:text-slate-400 dark:hover:bg-slate-800"
                      >
                        <Download className="h-4 w-4" />
                      </a>
                    )}
                    <button
                      type="button"
                      onClick={() => deleteClientDocument(client.id, doc.id)}
                      aria-label="حذف المستند"
                      className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/40"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Image Preview Lightbox */}
      {previewDataUrl && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/85 p-4"
          onClick={() => setPreviewDataUrl(null)}
        >
          <div className="max-h-[90vh] max-w-2xl space-y-2 text-center" onClick={(e) => e.stopPropagation()}>
            <img
              src={previewDataUrl}
              alt={previewTitle}
              referrerPolicy="no-referrer"
              className="max-h-[78vh] rounded-xl object-contain"
            />
            <div className="text-sm font-medium text-white">{previewTitle}</div>
          </div>
        </div>
      )}
    </div>
  );
};
