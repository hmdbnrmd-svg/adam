import React, { useState } from 'react';
import {
  AppWindow,
  Check,
  Edit3,
  FileText,
  MessageCircle,
  Phone,
  Plus,
  RefreshCw,
  Trash2,
} from 'lucide-react';
import { useRentalStore } from '../store/useRentalStore';
import type { Rental } from '../types/app';
import { daysUntil, formatArabicDate, formatWhatsAppUrl } from '../utils/helpers';
import { ClientAvatar } from './ClientAvatar';
import { ClientDocumentsSheet } from './ClientDocumentsSheet';
import { ConfirmModal } from './ConfirmModal';

interface ClientDetailsViewProps {
  clientId: string;
  onEditClient: (clientId: string) => void;
  onClientDeleted: () => void;
  onAddRentalForClient: (clientId: string) => void;
  onEditRental: (rental: Rental) => void;
}

export const ClientDetailsView: React.FC<ClientDetailsViewProps> = ({
  clientId,
  onEditClient,
  onClientDeleted,
  onAddRentalForClient,
  onEditRental,
}) => {
  const {
    clients,
    rentals,
    settings,
    deleteClient,
    renewRental,
    updateRental,
    deleteRental,
  } = useRentalStore();

  const [docsOpen, setDocsOpen] = useState(false);
  const [confirmDeleteClient, setConfirmDeleteClient] = useState(false);
  const [confirmDeleteRental, setConfirmDeleteRental] = useState<Rental | null>(null);

  const client = clients.find((c) => c.id === clientId);

  if (!client) {
    return (
      <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center dark:border-slate-800 dark:bg-slate-900">
        <p className="text-sm font-semibold text-slate-900 dark:text-white">
          لم يتم العثور على العميل
        </p>
      </div>
    );
  }

  const clientRentals = rentals.filter((r) => r.clientId === client.id);

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      {/* 1. Large Square/Box: Client Photo at top, Client Name underneath */}
      <section className="rounded-3xl border border-slate-200 bg-white p-6 text-center dark:border-slate-800 dark:bg-slate-900">
        <div className="flex justify-end gap-1.5">
          <button
            type="button"
            onClick={() => onEditClient(client.id)}
            aria-label="تعديل بيانات العميل"
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
          >
            <Edit3 className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => setConfirmDeleteClient(true)}
            aria-label="حذف العميل"
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-rose-200 text-rose-600 hover:bg-rose-50 dark:border-rose-900/60 dark:text-rose-400 dark:hover:bg-rose-950/30"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>

        {/* Client Photo */}
        <div className="flex flex-col items-center">
          <ClientAvatar name={client.name} src={client.avatarDataUrl} size="xl" />

          {/* Client Name directly under photo */}
          <h2 className="font-display mt-4 text-xl font-bold text-slate-900 dark:text-white">
            {client.name}
          </h2>

          {/* WhatsApp & Extra Contact info */}
          <div className="mt-2 flex flex-wrap items-center justify-center gap-3 text-xs text-slate-600 dark:text-slate-300">
            <a
              href={formatWhatsAppUrl(client.whatsapp)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl bg-emerald-600 px-3.5 py-1.5 font-semibold text-white hover:bg-emerald-700"
            >
              <MessageCircle className="h-4 w-4" />
              <span className="tabular-nums font-mono" dir="ltr">
                {client.whatsapp}
              </span>
            </a>

            {client.extraContact && (
              <span className="inline-flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
                <Phone className="h-3.5 w-3.5 text-slate-400" />
                <span>{client.extraContact}</span>
              </span>
            )}
          </div>

          {client.notes && (
            <p className="mt-3 max-w-md text-xs leading-relaxed text-slate-500 dark:text-slate-400">
              {client.notes}
            </p>
          )}
        </div>

        {/* 2. Directly under Name: 2 Small Rectangles -> Apps Count & Documents */}
        <div className="mt-6 grid grid-cols-2 gap-3">
          <div className="flex flex-col items-center justify-center rounded-2xl border border-slate-200 bg-slate-50/80 px-4 py-3.5 dark:border-slate-800 dark:bg-slate-800/50">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300">
              <AppWindow className="h-4 w-4 text-teal-600 dark:text-teal-400" />
              <span>عدد التطبيقات</span>
            </div>
            <div className="tabular-nums font-display mt-1 text-2xl font-bold text-slate-900 dark:text-white">
              {clientRentals.length}
            </div>
          </div>

          <button
            type="button"
            onClick={() => setDocsOpen(true)}
            className="flex flex-col items-center justify-center rounded-2xl border border-slate-200 bg-slate-50/80 px-4 py-3.5 transition-colors hover:border-teal-500/50 hover:bg-teal-50/50 dark:border-slate-800 dark:bg-slate-800/50 dark:hover:border-teal-500/40 dark:hover:bg-teal-950/30"
          >
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300">
              <FileText className="h-4 w-4 text-teal-600 dark:text-teal-400" />
              <span>المستندات</span>
            </div>
            <div className="tabular-nums font-display mt-1 text-2xl font-bold text-teal-700 dark:text-teal-400">
              {client.documents.length}
            </div>
          </button>
        </div>
      </section>

      {/* 3. Directly below: Rectangle labeled "التطبيقات" with "+ إضافة تطبيق" at the far left end */}
      <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white px-4 py-3 dark:border-slate-800 dark:bg-slate-900">
        <span className="font-display text-base font-bold text-slate-900 dark:text-white">
          التطبيقات
        </span>

        <button
          type="button"
          onClick={() => onAddRentalForClient(client.id)}
          className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl bg-teal-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-teal-800 dark:bg-teal-600 dark:hover:bg-teal-500"
        >
          <Plus className="h-4 w-4" />
          <span>إضافة تطبيق</span>
        </button>
      </div>

      {/* 4. Below "إضافة تطبيق": List of rented apps for this client */}
      <section className="space-y-3">
        {clientRentals.length === 0 ? (
          <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center dark:border-slate-800 dark:bg-slate-900">
            <AppWindow className="mx-auto h-9 w-9 text-slate-400" />
            <p className="mt-2.5 text-sm font-semibold text-slate-900 dark:text-white">
              لا توجد تطبيقات مستأجرة لهذا العميل
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              اضغط على زر «+ إضافة تطبيق» بالأعلى لتأجير تطبيق لهذا العميل.
            </p>
          </div>
        ) : (
          clientRentals.map((rental) => {
            const remaining = daysUntil(rental.endDate);
            const isExpired = remaining < 0;
            const isSoon = remaining >= 0 && remaining <= settings.reminderDays;
            const reminderMsg = `السلام عليكم ${client.name}، تذكير بخصوص اشتراك تطبيق (${rental.appName}) بتاريخ انتهاء ${rental.endDate}.`;

            return (
              <div
                key={rental.id}
                className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                      {rental.appName}
                    </h3>
                    <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-500 dark:text-slate-400">
                      <span className="tabular-nums">
                        من {formatArabicDate(rental.startDate)}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">
                        إلى {formatArabicDate(rental.endDate)}
                      </span>
                    </div>
                    {rental.accountInfo && (
                      <div className="mt-1 text-xs text-slate-600 dark:text-slate-300">
                        {rental.accountInfo}
                      </div>
                    )}
                  </div>

                  <div className="shrink-0 text-left">
                    <div className="tabular-nums font-display text-base font-bold text-slate-900 dark:text-white">
                      {rental.price} {settings.currency}
                    </div>
                    <div
                      className={`text-xs font-semibold ${
                        isExpired
                          ? 'text-rose-700 dark:text-rose-400'
                          : isSoon
                          ? 'text-amber-700 dark:text-amber-400'
                          : 'text-teal-700 dark:text-teal-400'
                      }`}
                    >
                      {isExpired
                        ? `منتهي منذ ${Math.abs(remaining)} يوم`
                        : `باقي ${remaining} يوم`}
                    </div>
                  </div>
                </div>

                {rental.notes && (
                  <p className="mt-2.5 text-xs text-slate-500 dark:text-slate-400">
                    {rental.notes}
                  </p>
                )}

                <div className="mt-3.5 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => renewRental(rental.id, 1)}
                      className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl bg-teal-50 px-3 py-1.5 text-xs font-semibold text-teal-800 hover:bg-teal-100 dark:bg-teal-950/60 dark:text-teal-300"
                    >
                      <RefreshCw className="h-3.5 w-3.5" />
                      <span>تجديد شهر</span>
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        updateRental(rental.id, {
                          paymentStatus:
                            rental.paymentStatus === 'paid' ? 'pending' : 'paid',
                        })
                      }
                      className={`inline-flex min-h-[38px] items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-semibold ${
                        rental.paymentStatus === 'paid'
                          ? 'border border-teal-200 bg-white text-teal-700 dark:border-teal-800 dark:bg-slate-900 dark:text-teal-400'
                          : 'bg-amber-100 text-amber-900 dark:bg-amber-950/60 dark:text-amber-300'
                      }`}
                    >
                      <Check className="h-3.5 w-3.5" />
                      <span>
                        {rental.paymentStatus === 'paid' ? 'مدفوع' : 'تأكيد السداد'}
                      </span>
                    </button>

                    <a
                      href={formatWhatsAppUrl(client.whatsapp, reminderMsg)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50/70 px-3 py-1.5 text-xs font-semibold text-emerald-800 hover:bg-emerald-100 dark:border-emerald-800/60 dark:bg-emerald-950/40 dark:text-emerald-300"
                    >
                      <MessageCircle className="h-3.5 w-3.5" />
                      <span>تذكير</span>
                    </a>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => onEditRental(rental)}
                      aria-label="تعديل الاشتراك"
                      className="flex h-9 w-9 items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
                    >
                      <Edit3 className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteRental(rental)}
                      aria-label="حذف الاشتراك"
                      className="flex h-9 w-9 items-center justify-center rounded-xl text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/40"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </section>

      {/* Documents Manager Sheet */}
      <ClientDocumentsSheet
        open={docsOpen}
        client={client}
        onClose={() => setDocsOpen(false)}
      />

      <ConfirmModal
        open={confirmDeleteClient}
        title="حذف العميل"
        message={`هل أنت متأكد من حذف العميل «${client.name}» وجميع تطبيقاته ومستنداته؟`}
        onCancel={() => setConfirmDeleteClient(false)}
        onConfirm={() => {
          deleteClient(client.id);
          setConfirmDeleteClient(false);
          onClientDeleted();
        }}
      />

      <ConfirmModal
        open={!!confirmDeleteRental}
        title="حذف اشتراك التطبيق"
        message={`هل تريد إزالة اشتراك «${confirmDeleteRental?.appName ?? ''}» من حساب العميل؟`}
        onCancel={() => setConfirmDeleteRental(null)}
        onConfirm={() => {
          if (confirmDeleteRental) deleteRental(confirmDeleteRental.id);
          setConfirmDeleteRental(null);
        }}
      />
    </div>
  );
};
