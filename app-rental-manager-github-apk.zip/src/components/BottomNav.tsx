import React from 'react';
import { AppWindow, Home, Plus, Star, Users } from 'lucide-react';
import type { MainTab } from '../types/app';

interface BottomNavProps {
  activeTab: MainTab | null;
  onSelectTab: (tab: MainTab) => void;
  onOpenQuickAdd: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onSelectTab,
  onOpenQuickAdd,
}) => {
  const navBtnClass = (isActive: boolean) =>
    `flex min-h-[48px] flex-col items-center justify-center gap-0.5 rounded-xl px-1 transition-colors ${
      isActive
        ? 'text-teal-700 dark:text-teal-400 font-semibold'
        : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
    }`;

  return (
    <nav
      aria-label="التنقل السفلي"
      className="fixed bottom-0 left-0 right-0 z-40 border-t border-slate-200 bg-white/95 pb-safe backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/95"
    >
      <div className="mx-auto grid h-16 max-w-5xl grid-cols-5 items-center px-2 sm:px-6">
        {/* 1. Home (Rightmost in RTL) */}
        <button
          type="button"
          onClick={() => onSelectTab('home')}
          className={navBtnClass(activeTab === 'home')}
        >
          <Home className="h-5 w-5" strokeWidth={activeTab === 'home' ? 2.4 : 1.9} />
          <span className="text-[11px] leading-none whitespace-nowrap">الرئيسية</span>
        </button>

        {/* 2. Apps */}
        <button
          type="button"
          onClick={() => onSelectTab('apps')}
          className={navBtnClass(activeTab === 'apps')}
        >
          <AppWindow className="h-5 w-5" strokeWidth={activeTab === 'apps' ? 2.4 : 1.9} />
          <span className="text-[11px] leading-none whitespace-nowrap">التطبيقات</span>
        </button>

        {/* 3. Center Floating/Popped Plus Button */}
        <div className="flex items-center justify-center">
          <button
            type="button"
            onClick={onOpenQuickAdd}
            aria-label="إضافة سريعة"
            className="-mt-5 flex h-14 w-14 items-center justify-center rounded-2xl border-4 border-slate-50 bg-teal-700 text-white shadow-lg shadow-teal-900/20 transition-transform hover:bg-teal-800 active:scale-95 dark:border-slate-950 dark:bg-teal-600 dark:hover:bg-teal-500"
          >
            <Plus className="h-7 w-7" strokeWidth={2.5} />
          </button>
        </div>

        {/* 4. Clients */}
        <button
          type="button"
          onClick={() => onSelectTab('clients')}
          className={navBtnClass(activeTab === 'clients')}
        >
          <Users className="h-5 w-5" strokeWidth={activeTab === 'clients' ? 2.4 : 1.9} />
          <span className="text-[11px] leading-none whitespace-nowrap">العملاء</span>
        </button>

        {/* 5. Ratings (Leftmost in RTL) */}
        <button
          type="button"
          onClick={() => onSelectTab('ratings')}
          className={navBtnClass(activeTab === 'ratings')}
        >
          <Star className="h-5 w-5" strokeWidth={activeTab === 'ratings' ? 2.4 : 1.9} />
          <span className="text-[11px] leading-none whitespace-nowrap">التقييمات</span>
        </button>
      </div>
    </nav>
  );
};
