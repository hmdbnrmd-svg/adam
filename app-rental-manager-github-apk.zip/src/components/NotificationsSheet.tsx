import React from 'react';
import { AlertTriangle, Bell, CheckCircle2, Clock, MessageCircle, X } from 'lucide-react';
import { useRentalStore } from '../store/useRentalStore';
import { formatArabicDate, formatWhatsAppUrl } from '../utils/helpers';

interface NotificationsSheetProps {
  open: boolean;
  onClose: () => void;
  onOpenClient: (clientId: string) => void;
}

export const NotificationsSheet: React.FC<NotificationsSheetProps> = ({
  open,
  onClose,
  onOpenClient,
}) => {
  const { notifications, renewRental } = useRentalStore();

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/55 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="flex max-h-[85vh] w-full max-w-lg flex-col rounded-t-3xl sm:rounded-2xl border border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-900"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto mt-3 h-1.5 w-10 rounded-full bg-slate-200 sm:hidden dark:bg-slate-700" />
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <Bell className="h-5 w-5 text-teal-600 dark:text-teal-400" />
            <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
              التنبيهات والمتابعة
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق التنبيهات"
            className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-5">
          {notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <CheckCircle2 className="h-10 w-10 text-teal-600 dark:text-teal-400" />
              <p className="mt-3 text-sm font-semibold text-slate-900 dark:text-white">
                لا توجد تنبيهات حالياً
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                جميع اشتراكات العملاء سارية ومسدد قيمتها.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {notifications.map((item) => {
                const isExpired = item.severity === 'expired';
                const isSoon = item.severity === 'soon';
                const reminderText = `السلام عليكم ${item.clientName}، تذكير بخصوص اشتراك تطبيق (${item.appName}) بتاريخ انتهاء ${item.endDate}.`;

                return (
                  <div
                    key={item.id}
                    className="rounded-xl border border-slate-200 bg-slate-50/70 p-3.5 dark:border-slate-800 dark:bg-slate-800/50"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          onOpenClient(item.clientId);
                        }}
                        className="text-right flex-1 min-w-0"
                      >
                        <div className="flex items-center gap-2">
                          {isExpired ? (
                            <AlertTriangle className="h-4 w-4 shrink-0 text-rose-600 dark:text-rose-400" />
                          ) : (
                            <Clock className="h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />
                          )}
                          <span className="truncate text-sm font-bold text-slate-900 dark:text-white">
                            {item.clientName}
                          </span>
                        </div>
                        <p className="mt-1 text-xs font-medium text-slate-700 dark:text-slate-300">
                          {item.message}
                        </p>
                        <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                          تاريخ الانتهاء: <span className="tabular-nums">{formatArabicDate(item.endDate)}</span>
                        </p>
                      </button>

                      <span
                        className={`shrink-0 text-xs font-semibold ${
                          isExpired
                            ? 'text-rose-700 dark:text-rose-400'
                            : isSoon
                            ? 'text-amber-700 dark:text-amber-400'
                            : 'text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        {isExpired ? 'منتهي' : isSoon ? 'قريباً' : 'معلق'}
                      </span>
                    </div>

                    <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-slate-200/70 pt-2.5 dark:border-slate-700/70">
                      <a
                        href={formatWhatsAppUrl(item.clientWhatsapp, reminderText)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-emerald-700"
                      >
                        <MessageCircle className="h-3.5 w-3.5" />
                        <span>تذكير واتساب</span>
                      </a>
                      <button
                        type="button"
                        onClick={() => renewRental(item.rentalId, 1)}
                        className="inline-flex min-h-[38px] items-center rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-800 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
                      >
                        تجديد شهر + سداد
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          onOpenClient(item.clientId);
                        }}
                        className="inline-flex min-h-[38px] items-center rounded-lg px-2.5 py-1.5 text-xs font-medium text-teal-700 hover:bg-teal-50 dark:text-teal-400 dark:hover:bg-teal-950/40"
                      >
                        فتح العميل
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
