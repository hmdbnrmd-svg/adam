import React from 'react';
import {
  AlertTriangle,
  AppWindow,
  Clock,
  MessageCircle,
  Plus,
  RefreshCw,
  Users,
  Wallet,
} from 'lucide-react';
import { useRentalStore } from '../store/useRentalStore';
import { daysUntil, formatArabicDate, formatWhatsAppUrl } from '../utils/helpers';
import { ClientAvatar } from './ClientAvatar';
import { PWAInstallButton } from './PWAInstallButton';

interface HomeViewProps {
  onOpenClient: (clientId: string) => void;
  onAddClient: () => void;
  onAddRental: () => void;
  onNavigateTab: (tab: 'apps' | 'clients' | 'ratings') => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onOpenClient,
  onAddClient,
  onAddRental,
  onNavigateTab,
}) => {
  const { clients, apps, rentals, notifications, settings, renewRental } = useRentalStore();

  const totalRevenue = rentals.reduce((acc, r) => acc + (r.price || 0), 0);
  const activeRentalsCount = rentals.filter((r) => daysUntil(r.endDate) >= 0).length;
  const clientMap = new Map(clients.map((c) => [c.id, c]));

  return (
    <div className="space-y-6">
      {/* Install App Card (automatically hides if already installed as standalone) */}
      <PWAInstallButton variant="card" />

      {/* Summary KPI Grid */}
      <section aria-label="ملخص الحساب">
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <button
            type="button"
            onClick={() => onNavigateTab('clients')}
            className="rounded-2xl border border-slate-200 bg-white p-4 text-right transition-colors hover:border-teal-500/40 dark:border-slate-800 dark:bg-slate-900"
          >
            <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
              <span className="text-xs font-medium">إجمالي العملاء</span>
              <Users className="h-4 w-4 text-teal-600 dark:text-teal-400" />
            </div>
            <div className="tabular-nums mt-2 font-display text-2xl font-bold text-slate-900 dark:text-white">
              {clients.length}
            </div>
            <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              عميل مسجل
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigateTab('apps')}
            className="rounded-2xl border border-slate-200 bg-white p-4 text-right transition-colors hover:border-teal-500/40 dark:border-slate-800 dark:bg-slate-900"
          >
            <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
              <span className="text-xs font-medium">التطبيقات النشطة</span>
              <AppWindow className="h-4 w-4 text-teal-600 dark:text-teal-400" />
            </div>
            <div className="tabular-nums mt-2 font-display text-2xl font-bold text-slate-900 dark:text-white">
              {activeRentalsCount}
            </div>
            <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              من أصل {apps.length} تطبيقات
            </div>
          </button>

          <div className="rounded-2xl border border-slate-200 bg-white p-4 text-right dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
              <span className="text-xs font-medium">قيمة التأجير</span>
              <Wallet className="h-4 w-4 text-teal-600 dark:text-teal-400" />
            </div>
            <div className="tabular-nums mt-2 font-display text-2xl font-bold text-slate-900 dark:text-white">
              {totalRevenue.toLocaleString('en-US')}
            </div>
            <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              {settings.currency} إجمالي الاشتراكات
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-4 text-right dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
              <span className="text-xs font-medium">تحتاج متابعة</span>
              <Clock className="h-4 w-4 text-amber-600 dark:text-amber-400" />
            </div>
            <div className="tabular-nums mt-2 font-display text-2xl font-bold text-slate-900 dark:text-white">
              {notifications.length}
            </div>
            <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              تنبيه انتهاء أو سداد
            </div>
          </div>
        </div>
      </section>

      {/* Quick Actions */}
      <section className="grid grid-cols-2 gap-3">
        <button
          type="button"
          onClick={onAddRental}
          className="flex min-h-[48px] items-center justify-center gap-2 rounded-xl bg-teal-700 px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-teal-800 dark:bg-teal-600 dark:hover:bg-teal-500"
        >
          <Plus className="h-4 w-4" />
          <span>تأجير تطبيق جديد</span>
        </button>
        <button
          type="button"
          onClick={onAddClient}
          className="flex min-h-[48px] items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-800 transition-colors hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
        >
          <Plus className="h-4 w-4 text-teal-600 dark:text-teal-400" />
          <span>إضافة عميل</span>
        </button>
      </section>

      {/* Two-column desktop split for Due Soon & Recent Rentals */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Expiring / Overdue */}
        <section className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
            <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
              اشتراكات قريبة الانتهاء أو منتهية
            </h2>
            <span className="tabular-nums text-xs font-semibold text-slate-500 dark:text-slate-400">
              {notifications.length} تنبيه
            </span>
          </div>

          {notifications.length === 0 ? (
            <p className="py-8 text-center text-sm text-slate-500 dark:text-slate-400">
              كل الاشتراكات سارية ولا توجد مستحقات متأخرة.
            </p>
          ) : (
            <div className="mt-3 space-y-3">
              {notifications.slice(0, 5).map((item) => {
                const isExpired = item.severity === 'expired';
                const reminderMsg = `السلام عليكم ${item.clientName}، تذكير بتجديد اشتراك (${item.appName}) حيث ينتهي بتاريخ ${item.endDate}.`;
                return (
                  <div
                    key={item.id}
                    className="rounded-xl border border-slate-200/80 bg-slate-50/70 p-3.5 dark:border-slate-800 dark:bg-slate-800/40"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <button
                        type="button"
                        onClick={() => onOpenClient(item.clientId)}
                        className="min-w-0 flex-1 text-right"
                      >
                        <div className="flex items-center gap-1.5">
                          <AlertTriangle
                            className={`h-4 w-4 shrink-0 ${
                              isExpired
                                ? 'text-rose-600 dark:text-rose-400'
                                : 'text-amber-600 dark:text-amber-400'
                            }`}
                          />
                          <span className="truncate text-sm font-bold text-slate-900 dark:text-white">
                            {item.clientName}
                          </span>
                        </div>
                        <div className="mt-1 text-xs text-slate-600 dark:text-slate-300">
                          {item.appName} <span aria-hidden="true">·</span>{' '}
                          <span className="tabular-nums">{formatArabicDate(item.endDate)}</span>
                        </div>
                      </button>

                      <span
                        className={`text-xs font-semibold whitespace-nowrap ${
                          isExpired
                            ? 'text-rose-700 dark:text-rose-400'
                            : 'text-amber-700 dark:text-amber-400'
                        }`}
                      >
                        {item.daysRemaining < 0
                          ? `منتهي منذ ${Math.abs(item.daysRemaining)} يوم`
                          : item.daysRemaining === 0
                          ? 'ينتهي اليوم'
                          : `باقي ${item.daysRemaining} أيام`}
                      </span>
                    </div>

                    <div className="mt-3 flex items-center gap-2">
                      <a
                        href={formatWhatsAppUrl(item.clientWhatsapp, reminderMsg)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-emerald-700"
                      >
                        <MessageCircle className="h-3.5 w-3.5" />
                        <span>واتساب</span>
                      </a>
                      <button
                        type="button"
                        onClick={() => renewRental(item.rentalId, 1)}
                        className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-800 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
                      >
                        <RefreshCw className="h-3.5 w-3.5" />
                        <span>تجديد شهر</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        {/* Recent Rentals */}
        <section className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
            <h2 className="font-display text-base font-bold text-slate-900 dark:text-white">
              أحدث التطبيقات المؤجرة
            </h2>
            <button
              type="button"
              onClick={() => onNavigateTab('clients')}
              className="text-xs font-semibold text-teal-700 hover:underline dark:text-teal-400"
            >
              عرض العملاء
            </button>
          </div>

          {rentals.length === 0 ? (
            <p className="py-8 text-center text-sm text-slate-500 dark:text-slate-400">
              لم تقم بتأجير أي تطبيقات بعد. اضغط على «تأجير تطبيق جديد» للبدء.
            </p>
          ) : (
            <div className="mt-3 divide-y divide-slate-100 dark:divide-slate-800">
              {rentals.slice(0, 6).map((rental) => {
                const client = clientMap.get(rental.clientId);
                if (!client) return null;
                const remaining = daysUntil(rental.endDate);
                return (
                  <button
                    key={rental.id}
                    type="button"
                    onClick={() => onOpenClient(client.id)}
                    className="flex w-full items-center justify-between gap-3 py-3 text-right transition-colors hover:bg-slate-50/80 rounded-xl px-2 dark:hover:bg-slate-800/40"
                  >
                    <div className="flex min-w-0 items-center gap-3">
                      <ClientAvatar name={client.name} src={client.avatarDataUrl} size="sm" />
                      <div className="min-w-0">
                        <div className="truncate text-sm font-semibold text-slate-900 dark:text-white">
                          {rental.appName}
                        </div>
                        <div className="truncate text-xs text-slate-500 dark:text-slate-400">
                          {client.name} <span aria-hidden="true">·</span>{' '}
                          <span className="tabular-nums">
                            {remaining >= 0 ? `باقي ${remaining} يوم` : 'منتهي'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="shrink-0 text-left">
                      <div className="tabular-nums text-sm font-bold text-slate-900 dark:text-white">
                        {rental.price} {settings.currency}
                      </div>
                      <div
                        className={`text-[11px] font-medium ${
                          rental.paymentStatus === 'paid'
                            ? 'text-teal-700 dark:text-teal-400'
                            : 'text-amber-700 dark:text-amber-400'
                        }`}
                      >
                        {rental.paymentStatus === 'paid' ? 'مدفوع' : 'بانتظار الدفع'}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
